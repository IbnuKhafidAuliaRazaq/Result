function pesan_err(pesan) {
    var temp = '<div class="alert alert-fill alert-icon alert-danger" role="alert"><em class="icon ni ni-alert-circle" ></em><h5>Perhatian </h5>' + pesan + '</div >';
    return temp;
}

function alert_success(pesan) {
    Swal.fire("Berhasil!", pesan, "success").then(() => { reload() });
}
function alert_gagal(pesan) {
    Swal.fire("Gagal!!", pesan, "error").then(() => { reload() });
}