CKEDITOR.plugins.add('datetime', {
    icons: 'datetime',
    init: function(editor){
        editor.ui.addButton('Datetime', {
            labelL: 'Insert Datetime',
            command: 'insertDateTime',
            toolbar: 'insert'
        })
    }
});