CKEDITOR.plugins.add('myimage', {
    icons: 'myimage',
    init: function(editor){
        editor.addCommand('insertMyimage', {
            exec: function(editor){
                imageUpload();
            }
        });
        editor.ui.addButton('Myimage',{
            label: 'Insert Gambar',
            command: 'insertMyimage',
            toolbar: 'insert'
        });
    }
});