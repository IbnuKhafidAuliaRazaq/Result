<?php

namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\Kategori_M;

class Kategori extends BaseController
{
	public function index()
	{
		return view('welcome_message');
	}
	public function read()
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$model = new Kategori_M();

		$kategori = $model ->findAll();

		$data = [
			'judul' => 'SELECT DATA',
			'kategori' => $kategori
		];
		
		return view('kategori/select', $data);
		}
	}
	function get_id($id = null){
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$data['data'] = 0;
		if (!empty($id)) {
			$kategori = $this->db->table('tblkategori');
			$query = $kategori->getWhere(['idkategori' => $id]);
			$data_kategori = $query->getRowArray();
			$data = [
				'data'		=>	1,
				'idkategori'	=>	$data_kategori['idkategori'],
				'kategori'		=>	$data_kategori['kategori'],
				'keterangan'	=>	$data_kategori['keterangan']
			];
			// var_dump($data_topik);
		}
		echo json_encode($data);
		}
	}
	public function insert(){
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$kategori = $this->db->table('tblkategori');
		
		$rules = [
			'tambah-kategori' => 'required|alpha_numeric_space',
			'tambah-keterangan' => 'required|alpha_numeric_space'
		];

		if ($this->validate($rules) == TRUE) {

			
			$data = [
				'kategori'	=>	$this->request->getPost('tambah-kategori'),
				'keterangan'		=>	$this->request->getPost('tambah-keterangan')
			];
	
			
			$kategori->insert($data);
	
			return redirect()->to(base_url('/admin/kategori'));

		}else {
			
			session()->setFlashdata('info-kategori', '<div class="alert alert-danger alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Tambah Kategori Gagal</strong>! Anda Melakukan Kesalahan Ketika Menginputkan Nilai. <button class="close" data-dismiss="alert"></button>
											</div>');
			return redirect()->to(base_url('/admin/kategori'));
		}

		}
	}
	public function ubah()
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$kategori = $this->db->table('tblkategori');

		$rules = [
			'edit-kategori' => 'required|alpha_numeric_space',
			'edit-keterangan' => 'required|alpha_numeric_space'
		];

		if ($this->validate($rules) == TRUE) {

			
			$data = [
				'kategori'		=>	$this->request->getPost('edit-kategori'),
				'keterangan'		=>	$this->request->getPost('edit-keterangan')
			];
			$id = $this->request->getPost('edit-id');
			$kategori->update($data, ['idkategori' => $id]);
	
			return redirect()->to(base_url('/admin/kategori'));

		}else {
			
			session()->setFlashdata('info-kategori', '<div class="alert alert-danger alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Edit Kategori Gagal</strong>! Anda Melakukan Kesalahan Ketika Menginputkan Nilai. <button class="close" data-dismiss="alert"></button>
											</div>');
			return redirect()->to(base_url('/admin/kategori'));
		}

		}
	}
	public function hapus($id=null)
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$kategori = $this->db->table('tblkategori');

		$kategori->delete(['idkategori' => $id]);

		return redirect()->to(base_url('/admin/kategori'));
		}
	}
	
}
