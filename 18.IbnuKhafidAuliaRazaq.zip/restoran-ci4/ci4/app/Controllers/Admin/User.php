<?php

namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\User_M;


class User extends BaseController
{
	public function index()
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$model = new User_M();

		$user = $model ->findAll();

		$data = [
			'user' => $user
		];
		
		return view('user/select', $data);}
	}
	function get_id($id = null){
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$data['data'] = 0;
		if (!empty($id)) {
			$user = $this->db->table('tbluser');
			$query = $user->getWhere(['iduser' => $id]);
			$data_user = $query->getRowArray();
			$data = [
				'data'		=>	1,
				'iduser'	=>	$data_user['iduser'],
				'user'	=>	$data_user['user'],
				'email'		=>	$data_user['email'],
			];
			// var_dump($data_topik);
		}
		echo json_encode($data);}
	}
	public function insert(){
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$user = $this->db->table('tbluser');
		
		$rules = [
			'tambah-user' => 'required|alpha_numeric_space|is_unique[tbluser.user]'
		];

		if ($this->validate($rules) == TRUE) {

			if($this->request->getPost('tambah-password') == $this->request->getPost('tambah-konfirmasi')){
				$data = [
					'user'	=>	$this->request->getPost('tambah-user'),
					'email'		=>	$this->request->getPost('tambah-email'),
					'password'		=>	password_hash($this->request->getPost('tambah-konfirmasi'), PASSWORD_DEFAULT),
					'level'		=>	$this->request->getPost('tambah-level'),
					'aktif' => 1
				];

				$user->insert($data);
				session()->setFlashdata('info-user', '<div class="alert alert-success alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Tambah User Berhasil</strong>! <button class="close" data-dismiss="alert"></button>
											</div>');
		
				return redirect()->to(base_url('/admin/user'));
			}else{
				session()->setFlashdata('info-user', '<div class="alert alert-danger alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Tambah User Gagal</strong>! Password & Konfirmasi Password Tidak Sesuai. <button class="close" data-dismiss="alert"></button>
											</div>');
				return redirect()->to(base_url('/admin/user'));
			}
			

		}else {
			
			session()->setFlashdata('info-user', '<div class="alert alert-danger alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Tambah User Gagal</strong>! Anda Melakukan Kesalahan Ketika Menginputkan Nilai. <button class="close" data-dismiss="alert"></button>
											</div>');
			return redirect()->to(base_url('/admin/user'));
		}
	}
	}
	public function hapus($id=null)
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$user = $this->db->table('tbluser');

		$user->delete(['iduser' => $id]);
		session()->setFlashdata('info-user', '<div class="alert alert-success alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Berhasil Menghapus User!</strong>!<button class="close" data-dismiss="alert"></button>
											</div>');

		return redirect()->to(base_url('/admin/user'));
		}
	}
	public function update($id=null,$status=null)
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$user = $this->db->table('tbluser');
		$data = [
			'aktif'		=>	$status
		];
		$user->update($data, ['iduser' => $id]);
		

		return redirect()->to(base_url('/admin/user'));
	}
	}
	public function ubah_email()
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$user = $this->db->table('tbluser');
		$id = $this->request->getPost('edit-email-id');
		$data = [
			'email'		=>	$this->request->getPost('edit-email')
		];
		$user->update($data, ['iduser' => $id]);
		

		return redirect()->to(base_url('/admin/user'));}
	}
	public function ubah_level($id=null)
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$user = $this->db->table('tbluser');

		$query = $user->getWhere(['iduser' => $id]);
		$data_user = $query->getRowArray();

		$data = [
			'level'		=>	$this->request->getPost('ubah-level')
		];
		$user->update($data, ['iduser' => $id]);
		
		session()->setFlashdata('info-user', '<div class="alert alert-success alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Ubah Level Berhasil!</strong>! Anda Menjadikan User = <strong>'.$data_user['user'].'</strong> Sebagai <strong>'.	$this->request->getPost('ubah-level').'</strong>. <button class="close" data-dismiss="alert"></button>
											</div>');

		return redirect()->to(base_url('/admin/user'));}
	}
    
}
