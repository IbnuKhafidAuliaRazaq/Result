<?php

namespace App\Controllers\Admin;
use App\Controllers\BaseController;

use App\Models\Menu_M;
use App\Models\Kategori_M;

class Menu extends BaseController
{
	public function index()
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$model = new Menu_M();

		$menu = $model ->findAll();
		$model = new Kategori_M();

		$kategori = $model ->findAll();

		$data = [
			'menu' => $menu,
			'kategori' => $kategori
		];
		
		return view('menu/select', $data);
		}
	}
	public function read(){
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();

		if(isset($_GET['idkategori'])){
			$id = $_GET['idkategori'];

			$menu = $this->db->table('tblmenu');
			$querymenu = $menu->getWhere(['idkategori' => $id])->getResultArray();

			$model = new Kategori_M();

			$kategori = $model ->findAll();
			$data = [
				'menu' => $querymenu,
				'kategori' => $kategori
			];
			
			return view('menu/select', $data);
		}
		}
	}
	public function insert(){
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$menu = $this->db->table('tblmenu');
		
		$rules = [
			'tambah-menu' => 'alpha_numeric_space',
			'tambah-gambar' => 'is_image[tambah-gambar]',
			'tambah-harga' => 'numeric'
		];

		if ($this->validate($rules) == TRUE) {

			$this->db = \Config\Database::connect();
			$kategori = $this->db->table('tblmenu');
			
			$data = [
				'idkategori'	=>	$this->request->getPost('idkategori'),
				'menu'		=>	$this->request->getPost('tambah-menu'),
				'gambar'		=>	$this->request->getFile('tambah-gambar')->getName(),
				'harga'		=>	$this->request->getPost('tambah-harga'),
			];
	
			
			if($this->request->getFile('tambah-gambar')->isValid()){
				$this->request->getFile('tambah-gambar')->move('uploads');
			}

			$kategori->insert($data);
	
			return redirect()->to(base_url('/admin/menu'));

		}else {
			
			
			
			$status = [
				'status' => 0,
				'pesan' => 'gagal'
			];
			
			echo json_encode($status);
			session()->setFlashdata('info', '<div class="alert alert-danger alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Tambah Data Gagal</strong>! Terdapat Kesalahan Ketika Anda Menginputkan Nilai. <button class="close" data-dismiss="alert"></button>
											</div>');
			return redirect()->to(base_url('/admin/menu'));
		}
		}
	}
	public function hapus($id=null)
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$menu = $this->db->table('tblmenu');

		$menu->delete(['idmenu' => $id]);

		return redirect()->to(base_url('/admin/menu'));
		}
	}
	public function form($id=null)
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();

		if (!empty($id)) {
			$menu = $this->db->table('tblmenu');
			$query = $menu->getWhere(['idmenu' => $id]);
			$data_menu = $query->getRowArray();
			$model = new Kategori_M();

			$kategori = $model ->findAll();
			$data = [
				'menu'	=>	$data_menu,
				'kategori' => $kategori
			];
			
		}

		return view('menu/form', $data);
		}
	}
	public function update(){
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$rules = [
			'edit-menu' => 'required|alpha_numeric_space',
			'edit-harga' => 'required|numeric',
		];
		$id = $this->request->getPost('idmenu');
		if($this->validate($rules) == TRUE){
			
			$file = $this->request->getFile('edit-gambar');
			$namafile = $file->getName();

			if(empty($namafile)){
				$namafile = $this->request->getPost('gambar');
			}else{
				$file->move('uploads');
			}

			$data = [
				'idkategori' => $this->request->getPost('idkategori'),
				'menu' => $this->request->getPost('edit-menu'),
				'gambar' => $namafile,
				'harga' => $this->request->getPost('edit-harga'),
			];

			$menu = $this->db->table('tblmenu');
			$menu->update($data, ['idmenu' => $id]);
			return redirect()->to(base_url('/admin/menu'));
		}else{
			session()->setFlashdata('info', '<div class="alert alert-danger alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Edit Menu Gagal</strong>! Anda Melakukan Kesalahan Ketika Menginputkan Nilai. <button class="close" data-dismiss="alert"></button>
											</div>');
			return redirect()->to(base_url('/admin/menu/form/'.$id.''));
		}
		
	}
	}
	public function update_status($id=null)
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$menu = $this->db->table('tblmenu');
		$data = [
			'aktif'		=>	$this->request->getPost('status-menu')
		];
		$menu->update($data, ['idmenu' => $id]);
		if($this->request->getPost('status-menu') == 0){
			session()->setFlashdata('info-status', '<div class="alert alert-danger alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Menu Diubah Menjadi Tidak Tersedia / Habis</strong>. <button class="close" data-dismiss="alert"></button>
											</div>');
		}else{
			session()->setFlashdata('info-status', '<div class="alert alert-success alert-icon alert-dismissible">
												<em class="icon ni ni-check-thick"></em> <strong>Menu Diubah Menjadi Tersedia</strong>. <button class="close" data-dismiss="alert"></button>
											</div>');
		}
		return redirect()->to(base_url('/admin/menu'));}
		
	}

}
