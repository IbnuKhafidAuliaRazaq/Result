<?php

namespace App\Controllers\Admin;
use App\Controllers\BaseController;

class Order extends BaseController
{
	public function index()
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();

        $result =  $this->db->table('vorder')->orderBy('idorder','ASC')->get()->getResultArray();

		$data = [
			'order' => $result
		];
		
		return view('order/select', $data);
		}
	}
	function pembayaran($id = null){
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		
		if (!empty($id)) {

			$order = $this->db->table('vorder');
			$query = $order->getWhere(['idorder' => $id]);
			$data_order = $query->getRowArray();

			$orderdetail = $this->db->table('vorderdetail');
			$query = $orderdetail->getWhere(['idorder' => $id]);
			$data_orderdetail = $query->getResultArray();

			$data = [
				'order'		=>	$data_order,
				'orderdetail' => $data_orderdetail
			];

			return view('order/form', $data);
		}}
	}
	public function bayar(){
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$order = $this->db->table('tblorder');

		$idorder = $this->request->getPost('bayar-id-order');
		$bayar = $this->request->getPost('bayar-bayar');
		$kembali = $this->request->getPost('bayar-kembali');

		$data = [
			'bayar' => $bayar,
			'kembali' => $kembali,
			'status' => 1
		];

		$query = $order->getWhere(['idorder' => $idorder])->getRowArray();
		$statusmeja = $query['idmeja'];

		$pilihmeja = [
			'aktif' => 1
		];

		$this->db->table('tblmeja')->update($pilihmeja, ['idmeja' => $statusmeja]);

		$order->update($data, ['idorder' => $idorder]);

		return redirect()->to(base_url('/admin/order'));}
	}
	public function cetak_struk($id = null){
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$orderdetail = $this->db->table('vorderdetail');
		$query = $orderdetail->getWhere(['idorder' => $id]);
		$data_orderdetail = $query->getResultArray();

		$data = [
			'struk' => $data_orderdetail
		];

		return view('order/cetak_struk', $data);}
	}
    
}
