<?php

namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\Meja_M;

class Meja extends BaseController
{
	public function index()
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$model = new Meja_M();

		$meja = $model ->findAll();

		$data = [
			'judul' => 'SELECT DATA',
			'meja' => $meja
		];
		
		return view('meja/select', $data);
		}
	}
	function get_id($id = null){
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$data['data'] = 0;
		if (!empty($id)) {
			$meja = $this->db->table('tblmeja');
			$query = $meja->getWhere(['idmeja' => $id]);
			$data_meja = $query->getRowArray();
			$data = [
				'data'		=>	1,
				'idmeja'	=>	$data_meja['idmeja'],
				'meja'		=>	$data_meja['meja']
			];
			// var_dump($data_topik);
		}
		echo json_encode($data);
		}
	}
	public function insert(){
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$meja = $this->db->table('tblmeja');
		
		$rules = [
			'tambah-meja' => 'required|alpha_numeric_space'
		];

		if ($this->validate($rules) == TRUE) {

			
			$data = [
				'meja'	=>	$this->request->getPost('tambah-meja'),
                'aktif' => 1
			];
	
			
			$meja->insert($data);
	
			return redirect()->to(base_url('/admin/meja'));

		}else {
			
			session()->setFlashdata('info-meja', '<div class="alert alert-danger alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Tambah meja Gagal</strong>! Anda Melakukan Kesalahan Ketika Menginputkan Nilai. <button class="close" data-dismiss="alert"></button>
											</div>');
			return redirect()->to(base_url('/admin/meja'));
		}

		}
	}
	public function ubah()
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$meja = $this->db->table('tblmeja');

		$rules = [
			'edit-meja' => 'required|alpha_numeric_space',
		];

		if ($this->validate($rules) == TRUE) {

			
			$data = [
				'meja'		=>	$this->request->getPost('edit-meja'),
			];
			$id = $this->request->getPost('edit-id');
			$meja->update($data, ['idmeja' => $id]);
	
			return redirect()->to(base_url('/admin/meja'));

		}else {
			
			session()->setFlashdata('info-meja', '<div class="alert alert-danger alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Edit meja Gagal</strong>! Anda Melakukan Kesalahan Ketika Menginputkan Nilai. <button class="close" data-dismiss="alert"></button>
											</div>');
			return redirect()->to(base_url('/admin/meja'));
		}

		}
	}
	public function hapus($id=null)
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$meja = $this->db->table('tblmeja');

		$meja->delete(['idmeja' => $id]);

		return redirect()->to(base_url('/admin/meja'));
		}
	}
	public function update_status($id=null)
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$meja = $this->db->table('tblmeja');
		$data = [
			'aktif'		=>	$this->request->getPost('status-meja')
		];
		$meja->update($data, ['idmeja' => $id]);
		if($this->request->getPost('status-meja') == 0){
			session()->setFlashdata('info-meja', '<div class="alert alert-danger alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Meja Pelanggan Di Penuh</strong>, Pelanggan Tidak akan dapat login!. <button class="close" data-dismiss="alert"></button>
											</div>');
		}else{
			session()->setFlashdata('info-meja', '<div class="alert alert-success alert-icon alert-dismissible">
												<em class="icon ni ni-check-thick"></em> <strong>Meja Pelanggan Di Kosong</strong>, Pelanggan akan kembali dapat login!. <button class="close" data-dismiss="alert"></button>
											</div>');
		}
		return redirect()->to(base_url('/admin/meja'));}
		
	}
}
