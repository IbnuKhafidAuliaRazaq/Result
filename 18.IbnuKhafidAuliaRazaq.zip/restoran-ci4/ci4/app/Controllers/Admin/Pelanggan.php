<?php

namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\Pelanggan_M;

class Pelanggan extends BaseController
{
	public function index()
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$model = new Pelanggan_M();

		$pelanggan = $model ->findAll();

		$data = [
			'pelanggan' => $pelanggan
		];
		
		return view('pelanggan/select', $data);}
	}
	public function hapus($id=null)
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$pelanggan = $this->db->table('tblpelanggan');

		$pelanggan->delete(['idpelanggan' => $id]);

		return redirect()->to(base_url('/admin/pelanggan'));}
	}
	public function update_status($id=null)
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$pelanggan = $this->db->table('tblpelanggan');
		$data = [
			'aktif'		=>	$this->request->getPost('status-pelanggan')
		];
		$pelanggan->update($data, ['idpelanggan' => $id]);
		if($this->request->getPost('status-pelanggan') == 0){
			session()->setFlashdata('info-status', '<div class="alert alert-danger alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Status Pelanggan Di Nonaktifkan</strong>, Pelanggan Tidak akan dapat login!. <button class="close" data-dismiss="alert"></button>
											</div>');
		}else{
			session()->setFlashdata('info-status', '<div class="alert alert-success alert-icon alert-dismissible">
												<em class="icon ni ni-check-thick"></em> <strong>Status Pelanggan Di Aktifkan</strong>, Pelanggan akan kembali dapat login!. <button class="close" data-dismiss="alert"></button>
											</div>');
		}
		return redirect()->to(base_url('/admin/pelanggan'));}
		
	}
	
    
}
