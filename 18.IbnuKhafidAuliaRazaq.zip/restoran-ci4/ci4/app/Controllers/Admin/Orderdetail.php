<?php

namespace App\Controllers\Admin;
use App\Controllers\BaseController;

use App\Models\Orderdetail_M;

class Orderdetail extends BaseController
{
	public function index()
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$model = new Orderdetail_M();

		$orderdetail = $model ->findAll();

		$data = [
			'orderdetail' => $orderdetail
		];

		return view('orderdetail/select', $data);}
	}
	public function cari(){
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();

		$awal = $this->request->getPost('awal');
		$sampai = $this->request->getPost('sampai');

		$sql = "SELECT * FROM vorderdetail WHERE tglorder BETWEEN '$awal' AND '$sampai' ";

		$orderdetail = $this->db->query($sql)->getResultArray();

		$data = [
			'orderdetail' => $orderdetail
		];

		return view('orderdetail/cari', $data);
		}
	}
}
