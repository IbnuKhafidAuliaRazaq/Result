<?php

namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\User_M;


class Login extends BaseController
{
	public function index()
	{
        
        if($this->request->getMethod() == 'post'){
            $email = $this->request->getPost('email');
            $password = $this->request->getPost('password');
            
            $model = new User_M();
            $user = $model->where(['email' => $email, 'aktif' => 1 ])->first();

            if(!empty($user)){
                if(password_verify($password, $user['password'])){
                    $this->setSession($user);
                    return redirect()->to(base_url('/admin'));
                }else{
                    session()->setFlashdata('info-login-admin', '<div class="alert alert-danger alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Login Admin Gagal</strong>! Password Yang Anda Masukkan Salah. <button class="close" data-dismiss="alert"></button>
											</div>');
			        return redirect()->to(base_url('/admin/login'));
                }
                
            }else{
                session()->setFlashdata('info-login-admin', '<div class="alert alert-danger alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Login Admin Gagal</strong>! Email / Yang Anda Masukkan Salah. <button class="close" data-dismiss="alert"></button>
											</div>');
			    return redirect()->to(base_url('/admin/login'));
            }
        }else{

        }
		return view('template/login_admin');
	}

    public function setSession($user){
        $data = [
            'user' => $user['user'],
            'email' => $user['email'],
            'level' => $user['level'],
            'loggedIn' => true
        ];

        session()->set('administrator' ,$data);
    }

    public function logout(){
        session()->remove('administrator');
		
		return redirect()->to(base_url('/admin/login'));
    }
}
