<?php

namespace App\Controllers;

class Home extends BaseController
{
	public function index()
	{
		$this->db = \Config\Database::connect();
		$kategori = $this->db->table('tblkategori');
		$menu = $this->db->table('tblmenu');
		$vorderdetail = $this->db->table('vorderdetail');
		$cart = \Config\Services::cart();

		$data = [
			'kategori' => $kategori->get()->getResultArray(),
			'menu' => $menu->get()->getResultArray(),
			'vorderdetail' => $vorderdetail->get()->getResultArray(),
			'cart'=> $cart->contents()
		];

		return view('home', $data);
	}
	public function kategori($id = null){
		$this->db = \Config\Database::connect();
		$kategori = $this->db->table('tblkategori')->getWhere(['idkategori' => $id])->getResultArray();
		$menu = $this->db->table('tblmenu')->getWhere(['idkategori' => $id])->getResultArray();
		$vorderdetail = $this->db->table('vorderdetail');
		$cart = \Config\Services::cart();

		$data = [
			'kategori' => $kategori,
			'menu' => $menu,
			'vorderdetail' => $vorderdetail->get()->getResultArray(),
			'cart'=> $cart->contents()
		];

		return view('home', $data);
	}
}
