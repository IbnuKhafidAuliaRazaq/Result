<?php

namespace App\Controllers\Front;

use App\Controllers\BaseController;

class Menu extends BaseController
{
	public function index()
	{
        if($this->request->getPost('idmeja') == 0){
            session()->setFlashdata('info-meja', '<div class="alert alert-danger alert-icon alert-dismissible">
												<em class="icon ni ni-cross-circle"></em> <strong>Anda Belum Memilih Meja</strong>!<button class="close" data-dismiss="alert"></button>
											</div>');
			return redirect()->to(base_url('/front/pilihmeja'));
        }else{
            $this->db = \Config\Database::connect();
            $kategori = $this->db->table('tblkategori');
            $menu = $this->db->table('tblmenu');
            $vorderdetail = $this->db->table('vorderdetail');
            $cart = \Config\Services::cart();
    
            $data = [
                'kategori' => $kategori->get()->getResultArray(),
                'menu' => $menu->get()->getResultArray(),
                'vorderdetail' => $vorderdetail->get()->getResultArray(),
                'cart'=> $cart->contents(),
            ];

            $meja = [
                'idmeja' => $this->request->getPost('idmeja')
            ];

            $upmeja = [
                'aktif' => 0
            ];

            session()->set('idmeja' ,$meja);

            if($this->request->getPost('idmeja') == 9){
                $this->db->table('tblmeja')->update($upmeja, ['idmeja' => $this->request->getPost('idmeja')]);
    
            }
            
            return view('front/menu', $data);
        }
	}
	public function kategori($id = null){
		$this->db = \Config\Database::connect();
		$kategori = $this->db->table('tblkategori')->getWhere(['idkategori' => $id])->getResultArray();
		$menu = $this->db->table('tblmenu')->getWhere(['idkategori' => $id])->getResultArray();
		$vorderdetail = $this->db->table('vorderdetail');
		$cart = \Config\Services::cart();

		$data = [
			'kategori' => $kategori,
			'menu' => $menu,
			'vorderdetail' => $vorderdetail->get()->getResultArray(),
			'cart'=> $cart->contents()
		];

		return view('front/menu', $data);
	}
    
    public function select(){
		$this->db = \Config\Database::connect();
            $kategori = $this->db->table('tblkategori');
            $menu = $this->db->table('tblmenu');
            $vorderdetail = $this->db->table('vorderdetail');
            $cart = \Config\Services::cart();
    
            $data = [
                'kategori' => $kategori->get()->getResultArray(),
                'menu' => $menu->get()->getResultArray(),
                'vorderdetail' => $vorderdetail->get()->getResultArray(),
                'cart'=> $cart->contents(),
            ];

            return view('front/menu', $data);
	}
    
}
