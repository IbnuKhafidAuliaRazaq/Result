<?php

namespace App\Controllers\Front;
use App\Controllers\BaseController;

class Cart extends BaseController
{
	public function index()
	{   if(!empty(session('pelanggan'))){
            if(empty(session('idmeja'))){
                session()->setFlashdata('info-meja', '<div class="alert alert-danger alert-icon alert-dismissible">
                                                    <em class="icon ni ni-cross-circle"></em> <strong>Anda Belum Memilih Meja</strong>!<button class="close" data-dismiss="alert"></button>
                                                </div>');
                return redirect()->to(base_url('/front/pilihmeja'));
            }else{
                $cart = \Config\Services::cart();
                $this->db = \Config\Database::connect();
                $meja = $this->db->table('tblmeja');
        
                $data = [
                    'cart' => $cart->contents(),
                    'total' => $cart->total(),
                    'meja' => $meja->getWhere(['idmeja' => session('idmeja')['idmeja']])->getRowArray()
                ];
                return view('template/cart',$data);
                
            }
        }else{
            return redirect()->to(base_url('/front/login'));
        }
	}
    public function addToCart($id = null){
        $this->db = \Config\Database::connect();

        $menu = $this->db->table('tblmenu');
		$query = $menu->getWhere(['idmenu' => $id]);
		$data_menu = $query->getRowArray();
        

        $cart = \Config\Services::cart();
        $cart->insert(array(
            'id'      => $data_menu['idmenu'],
            'qty'     => 1,
            'price'   => $data_menu['harga'],
            'name'    => $data_menu['menu'],
            'gambar' => $data_menu['gambar']
        ));
        return redirect()->to(base_url('/front/menu/select'));
    }
    public function hapus($id = null)
    {
        $cart = \Config\Services::cart();

        $cart->remove($id);
        return redirect()->to(base_url('/front/cart'));
    }
    public function plus($qty, $rowid)
    {
        $cart = \Config\Services::cart();
        $jumlah = $qty + 1;
        $data = array(
            'rowid' => $rowid,
            'qty' => $jumlah
        );
        $cart->update($data);
        return redirect()->to(base_url('/front/cart'));
    }
    public function minus($qty, $rowid)
    {
        $cart = \Config\Services::cart();
        $jumlah = $qty - 1;
        $data = array(
            'rowid' => $rowid,
            'qty' => $jumlah
        );

        if ($jumlah == 0) {
            $cart->remove($rowid);
        } else {
            $cart->update($data);
        }

        return redirect()->to(base_url('/front/cart'));
    }
    public function checkout(){
        $db = \Config\Database::connect();
        $cart = \Config\Services::cart();

        if(empty(session()->get('pelanggan'))){
            return redirect()->to(base_url('/login'));
        }else{
            date_default_timezone_set('Asia/Jakarta');
            $order = array(
                'idpelanggan' => session('pelanggan')['idpelanggan'],
                'idmeja' => session('idmeja')['idmeja'],
                'tglorder' => date('Y-m-d H:i:s'),
                'total' => $cart->total(),
                'bayar' => 0,
                'kembali' => 0,
                //'kode'  => $gpass,
                'status' => 0,
            );
            
            $db->table('tblorder')->insert($order);

            $idorder = $db->insertID();

            foreach ($cart->contents() as $item) {
                $data = array(
                    'idorder' => $idorder,
                    'idmenu' => $item['id'],
                    'jumlah'  => $item['qty'],
                    'hargajual' => $item['price'],
                );
                
                $db->table('tblorderdetail')->insert($data);
            }
            $cart->destroy();
            session()->remove('idmeja');
            session()->setFlashdata('info-checkout', '<div class="alert alert-success alert-icon alert-dismissible">
                                            <strong>Pesanan Anda Telah Masuk</strong>! <a href="'.base_url().'">Kembali Ke Halaman Utama!</a><button class="close" data-dismiss="alert"></button>
                                        </div>');
            return redirect()->to(base_url('/front/cart/success/'.$idorder.''));
    }
    

    }
    public function success($id = null){
        $db = \Config\Database::connect();

        $order = $db->table('vorder')->getWhere(['idorder' => $id])->getRowArray();
        $orderdetail = $db->table('vorderdetail')->getWhere(['idorder' => $id])->getResultArray();

        $data = [
            'vorder' => $order,
            'vorderdetail' => $orderdetail
        ];

        return view('template/success', $data);
    }
    public function cetak($id = null){
        $db = \Config\Database::connect();

        $order = $db->table('vorder')->getWhere(['idorder' => $id])->getRowArray();
        $orderdetail = $db->table('vorderdetail')->getWhere(['idorder' => $id])->getResultArray();

        $data = [
            'vorder' => $order,
            'vorderdetail' => $orderdetail
        ];

        return view('template/cetak', $data);
    }
}
