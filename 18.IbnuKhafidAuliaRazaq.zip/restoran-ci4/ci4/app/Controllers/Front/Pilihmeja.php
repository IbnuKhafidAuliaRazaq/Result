<?php

namespace App\Controllers\Front;
use App\Controllers\BaseController;
use App\Models\Meja_M;

class Pilihmeja extends BaseController
{
	public function index()
	{   
        $model = new Meja_M();

		$meja = $model ->findAll();

		$data = [
			'judul' => 'SELECT DATA',
			'meja' => $meja
		];
        return view('front/pilihmeja', $data);
    }
    
    
}
