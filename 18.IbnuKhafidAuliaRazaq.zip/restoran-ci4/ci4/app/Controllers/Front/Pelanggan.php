<?php

namespace App\Controllers\Front;
use App\Controllers\BaseController;
use App\Models\Pelanggan_M;

class Pelanggan extends BaseController
{
	public function select($id = null)
	{
		if(empty(session()->get('pelanggan'))){
            return redirect()->to(base_url());
        }else{
            $this->db = \Config\Database::connect();
            $pelanggan = $this->db->table('tblpelanggan')->getWhere(['idpelanggan' => $id])->getRowArray();

            $data = [
                'pelanggan' => $pelanggan
            ];
		
		   return view('front/pelanggan', $data);

        }
	}
	
	public function update($id=null)
	{
		if(empty(session()->get('administrator'))){
            return redirect()->to(base_url('/admin/login'));
        }else{
		$this->db = \Config\Database::connect();
		$pelanggan = $this->db->table('tblpelanggan');
		$data = [
			'pelanggan' => $this->request->getPost('nama'),
			'alamat' => $this->request->getPost('alamat'),
			'telp' => $this->request->getPost('telepon'),
			'email' => $this->request->getPost('email'),
		];
		$pelanggan->update($data, ['idpelanggan' => $id]);
		
		return redirect()->to(base_url());}
		
	}
	
    
}
