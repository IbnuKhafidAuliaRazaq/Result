<?php

namespace App\Controllers\Front;
use App\Controllers\BaseController;

class Registrasi extends BaseController
{
	public function index()
	{
		return view('template/registrasi');
	}
    public function daftar(){

        $this->db = \Config\Database::connect();
		$pelanggan = $this->db->table('tblpelanggan');

        if($this->request->getPost('password') == $this->request->getPost('konfirmasi-password')){
            $data = [
                'pelanggan' => $this->request->getPost('nama'),
                'alamat' => $this->request->getPost('alamat'),
                'telp' => $this->request->getPost('telepon'),
                'email' => $this->request->getPost('email'),
                'password' => password_hash($this->request->getPost('konfirmasi-password'), PASSWORD_DEFAULT),
                'aktif' => 1
            ];
    
            $pelanggan->insert($data);
    
            session()->setFlashdata('info-regis', '<div class="alert alert-success alert-icon alert-dismissible">
                                                    <em class="icon ni ni-cross-circle"></em> <strong>Registrasi Berhasil</strong>! Silahkan Login <a href="'.base_url().'/front/login">Disini<a/>. <button class="close" data-dismiss="alert"></button>
                                                </div>');
            return redirect()->to(base_url('/front/registrasi'));
        }else{
            session()->setFlashdata('info-regis', '<div class="alert alert-danger alert-icon alert-dismissible">
                                                    <em class="icon ni ni-cross-circle"></em> <strong>Registrasi Gagal</strong>! Password Tidak Cocok. <button class="close" data-dismiss="alert"></button>
                                                </div>');
            return redirect()->to(base_url('/front/registrasi'));
        }


    }
}
