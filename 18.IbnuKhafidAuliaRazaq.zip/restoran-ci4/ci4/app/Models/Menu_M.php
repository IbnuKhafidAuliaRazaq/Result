<?php 

namespace App\Models;
use CodeIgniter\Model;


class Menu_M extends Model{
    protected $table = 'tblmenu';
    protected $allowedFields = ['kategori', 'keterangan'];
    protected $primaryKey = 'idkategori';
}

?>