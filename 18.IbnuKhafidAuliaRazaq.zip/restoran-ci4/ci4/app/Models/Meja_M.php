<?php 

namespace App\Models;
use CodeIgniter\Model;

class Meja_M extends Model{
    protected $table = 'tblmeja';
}

?>