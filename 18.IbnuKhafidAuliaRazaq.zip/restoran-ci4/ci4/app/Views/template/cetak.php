
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>OneResto | Cart</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link rel="shortcut icon" href="<?= base_url() ?>/assets/img/logo-resto.png">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link rel="stylesheet" href="<?= base_url() ?>/src/assets/css/dashlite.css?ver=1.6.0">
    <link id="skin-default" rel="stylesheet" href="<?= base_url() ?>/src/assets/css/theme.css?ver=1.6.0"> 

    <script src="<?php echo base_url('/assets/js/bundle.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/js/scripts.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/jquery.dataTables.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/dataTables.bootstrap4.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/dataTables.responsive.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/responsive.bootstrap4.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/js/example-sweetalert.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/ckeditor/ckeditor.js') ?>"></script>
    <script src="<?php echo base_url('/assets/ckeditor/adapters/jquery.js') ?>"></script>

  <link rel="stylesheet" href="<?= base_url() ?>/src/assets/css/dashlite.css?ver=1.6.0">
  <link id="skin-default" rel="stylesheet" href="<?= base_url() ?>/src/assets/css/theme.css?ver=1.6.0"> 
  <link href="<?= base_url() ?>/assets-front/vendor/aos/aos.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets-front/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets-front/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets-front/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets-front/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets-front/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->

  <link href="<?= base_url() ?>/assets-front/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: BizLand - v3.1.0
  * Template URL: https://bootstrapmade.com/bizland-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Hero Section ======= -->
    <div class="container" style="margin-top: 100px;" data-aos="zoom-out" data-aos-delay="100">
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10">
                <div class="card card-bordered">
                        <div class="card-body">
                            
                        <div class="invoice">
                                <div class="invoice-action">
                                    <a class="btn btn-primary" href="<?= base_url() ?>/front/cart/cetak/<?= $vorder['idorder'] ?>" target="_blank">
                                        <em class="icon ni ni-printer-fill"></em>
                                    </a>
                                </div>
                                <div class="invoice-wrap">
                                    <div class="invoice-brand text-center">
                                        <h3><span>000<?= $vorder['idorder'] ?></span></h3>
                                    </div>
                                <div class="invoice-head">
                                    <div class="invoice-contact">
                                    <div class="invoice-contact-info">
                                        <h4 class="title">OneResto!</h4>
                                        <ul class="list-plain">
                                            <li>
                                                <em class="icon ni ni-map-pin-fill"></em>
                                                <span>Sruni, Gedangan, Jawa Timur</span>
                                            </li>
                                            <li>
                                                <em class="icon ni ni-call-fill"></em>
                                                <span>+62895335602756</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="invoice-desc">
                                    <ul class="list-plain">
                                        <li class="invoice-id"><span>Kode : 000<?= $vorder['idorder'] ?></span></li>
                                        <li class="invoice-date">
                                            <span>Date : <?= $vorder['tglorder'] ?></span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="invoice-bills">
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th class="w-60">Menu</th>
                                                <th>Price</th>
                                                <th>Qty</th>
                                                <th>Jumlah</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($vorderdetail as $key) : ?>
                                                <tr>
                                                    <td><?= $key['menu'] ?></td>
                                                    <td>Rp.<?= number_format($key['hargajual']) ?></td>
                                                    <td><?= $key['jumlah'] ?></td>
                                                    <td>Rp.<?= number_format($key['jumlah'] * $key['hargajual']) ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                            <tr>
                                                <td colspan="2"></td>
                                                <td >Grand Total</td>
                                                <td>Rp.<?= number_format($vorder['total']) ?></td>
                                            </tr>
                                    </table>
                                    <div class="nk-notes ff-italic fs-12px text-soft"> Ingat Kode / Cetak Agar Dapat Melakukan Pembayaran Di Kasir. </div>
                                    </div></div></div></div>
                        </div>
                    </div>
                        </div>
                    </div>

    

  <!-- Vendor JS Files -->
  <script src="<?= base_url() ?>/assets-front/vendor/aos/aos.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/php-email-form/validate.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/purecounter/purecounter.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/waypoints/noframework.waypoints.js"></script>

  <!-- Template Main JS File -->
  <script src="<?= base_url() ?>/assets-front/js/main.js"></script>

  <script>
    window.print();
  </script>

</body>

</html>