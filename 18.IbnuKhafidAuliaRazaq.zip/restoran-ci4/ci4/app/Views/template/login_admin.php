<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="@@page-discription">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="<?= base_url() ?>/assets/img/logo-resto.png">
    <!-- Page Title  -->
    <title>OneResto | Admin</title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?= base_url() ?>/src/assets/css/dashlite.css?ver=1.6.0">
    <link id="skin-default" rel="stylesheet" href="<?= base_url() ?>/src/assets/css/theme.css?ver=1.6.0"> 
    
    <script src="<?php echo base_url('/assets/js/bundle.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/js/scripts.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/jquery.dataTables.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/dataTables.bootstrap4.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/dataTables.responsive.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/responsive.bootstrap4.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/js/example-sweetalert.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/ckeditor/ckeditor.js') ?>"></script>
    <script src="<?php echo base_url('/assets/ckeditor/adapters/jquery.js') ?>"></script>
</head>

<body class="nk-body bg-lighter npc-general ">

<div class="nk-block nk-block-middle nk-auth-body mt-3">
    <div class="brand-logo pb-5">
        <a href="/demo3/index.html" class="logo-link">
            <img class="logo-img logo-img-lg" src="<?= base_url() ?>/assets/img/logo-dashlite.png" alt="logo">
        </a>
    </div>
    <div class="nk-block-head">
        <div class="nk-block-head-content">
            <h5 class="nk-block-title">Log-In Admin</h5>
            <div class="nk-block-des">
            <p>Masuk Administrator Restoran Menggunakan Email Dan Password Yang Diberikan Admin.</p>
            <?= session()->getFlashdata('info-login-admin') ?>
        </div>
    </div>
</div>
<form action="<?= base_url() ?>/admin/login" method="post">
    <div class="form-group">
        <div class="form-label-group">
            <label class="form-label" for="default-01">Email</label>
            <a class="link link-primary link-sm" tabindex="-1" href="#">Butuh Bantuan?</a>
        </div>
        <input required type="email" name="email" class="form-control form-control-lg" id="default-01" placeholder="Masukkan Email Anda">
    </div>
    <div class="form-group">
        <div class="form-label-group">
            <label class="form-label" for="password">Password</label>
            <a class="link link-primary link-sm" tabindex="-1" href="/demo3/pages/auths/auth-reset.html">Lupa Password?</a>
        </div>
        <div class="form-control-wrap">
            </a><input required type="password" name="password" class="form-control form-control-lg" id="password" placeholder="Enter your passcode">
        </div>
    </div>
    <div class="form-group">
        <button class="btn btn-lg btn-primary btn-block">Sign in</button>
    </div>
</form>
    <div class="form-note-s2 pt-4"> New on our platform? 
        <a href="/demo3/pages/auths/auth-register.html">Create an account</a>
    </div>
    <div class="text-center pt-4 pb-3">
        <h6 class="overline-title overline-title-sap">
            <span>OR</span>
        </h6>
    </div>
    <ul class="nav justify-center gx-4">
        <li class="nav-item"><a class="nav-link" href="#">Facebook</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Google</a></li>
    </ul>
    <div class="text-center mt-5">
        <span class="fw-500">I don't have an account? <a href="#">Try 15 days free</a></span>
    </div>
</div>
<script src="<?php echo base_url('public/assets/js/app.js') ?>"></script>
    <script>
        function reload() {
            window.location.reload();
        }
        
        function modalProses(){
          $("#modal-proses").modal('show');
        }
        function modalBerhasil(){
          $("#modal-berhasil").modal('show');
        }
    </script>
</body>

</html>