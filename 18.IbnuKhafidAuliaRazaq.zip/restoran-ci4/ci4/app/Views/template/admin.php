
<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="@@page-discription">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="<?= base_url() ?>/assets/img/logo-resto.png">
    <!-- Page Title  -->
    <title>OneResto | Admin</title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?= base_url() ?>/src/assets/css/dashlite.css?ver=1.6.0">
    <link id="skin-default" rel="stylesheet" href="<?= base_url() ?>/src/assets/css/theme.css?ver=1.6.0"> 
    
    <script src="<?php echo base_url('/assets/js/bundle.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/js/scripts.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/jquery.dataTables.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/dataTables.bootstrap4.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/dataTables.responsive.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/responsive.bootstrap4.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/js/example-sweetalert.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/ckeditor/ckeditor.js') ?>"></script>
    <script src="<?php echo base_url('/assets/ckeditor/adapters/jquery.js') ?>"></script>
</head>

<body class="nk-body bg-lighter npc-general has-sidebar ">

    
    <div class="nk-app-root">
        <!-- main @s -->
        <div class="nk-main ">
            <!-- sidebar @s -->
            <div class="nk-sidebar nk-sidebar-fixed is-dark " data-content="sidebarMenu">
                <div class="nk-sidebar-element nk-sidebar-head">
                    <div class="nk-sidebar-brand">
                        <a href="" class="logo-link nk-sidebar-logo">
                        <img class="logo-img logo-img-lg" src="<?= base_url() ?>/assets/img/logo-dashlite.png" alt="logo">
                            <span class="nio-version">ONERESTO</span>
                        </a>
                    </div>
                    <div class="nk-menu-trigger mr-n2">
                        <a href="#" class="nk-nav-toggle nk-quick-nav-icon d-xl-none" data-target="sidebarMenu"><em class="icon ni ni-arrow-left"></em></a>
                    </div>
                </div><!-- .nk-sidebar-element -->
                <div class="nk-sidebar-element">
                    <div class="nk-sidebar-content">
                        <div class="nk-sidebar-menu" data-simplebar>
                            <ul class="nk-menu">
                                <li class="nk-menu-item">
                                    <a href="<?= base_url('/admin') ?>" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-dashlite"></em></span>
                                        <span class="nk-menu-text">Dashboard</span>
                                    </a>
                                </li><!-- .nk-menu-item -->
                                
                                <li class="nk-menu-heading">
                                    <h6 class="overline-title text-primary-alt">APLIKASI</h6>
                                </li><!-- .nk-menu-heading -->
                                <li class="nk-menu-item has-sub">
                                    <a href="#" class="nk-menu-link nk-menu-toggle">
                                        <span class="nk-menu-icon"><em class="icon ni ni-grid-alt"></em></span>
                                        <span class="nk-menu-text">MASTER</span>
                                    </a>
                                    <ul class="nk-menu-sub">
                                    
                                    <?php if(session()->get('administrator')['level'] == 'admin') : ?>
                                        <li class="nk-menu-item">
                                            <a href="<?= base_url('/admin/kategori') ?>" class="nk-menu-link"><span class="nk-menu-text"><em class="icon ni ni-view-grid-wd"></em> Kategori</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="<?= base_url('/admin/menu') ?>" class="nk-menu-link"><span class="nk-menu-text"><em class="icon ni ni-view-list-fill"></em> Menu</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="<?= base_url('/admin/pelanggan') ?>" class="nk-menu-link"><span class="nk-menu-text"><em class="icon ni ni-user-fill"></em> Pelanggan</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="<?= base_url('/admin/order') ?>" class="nk-menu-link"><span class="nk-menu-text"><em class="icon ni ni-wallet-fill"></em> Pembayaran</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="<?= base_url('/admin/orderdetail') ?>" class="nk-menu-link"><span class="nk-menu-text"><em class="icon ni ni-wallet-out"></em> Detail Order</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="<?= base_url('/admin/user') ?>" class="nk-menu-link"><span class="nk-menu-text"><em class="icon ni ni-account-setting-fill"></em></em> User-admin</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="<?= base_url('/admin/meja') ?>" class="nk-menu-link"><span class="nk-menu-text"><em class="icon ni ni-grid-fill"></em> Meja</span></a>
                                        </li>
                                    <?php endif; ?>  
                                    <?php if(session()->get('administrator')['level'] == 'kasir') : ?>
                                        <li class="nk-menu-item">
                                            <a href="<?= base_url('/admin/order') ?>" class="nk-menu-link"><span class="nk-menu-text"><em class="icon ni ni-wallet-fill"></em> Pembayaran</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="<?= base_url('/admin/orderdetail') ?>" class="nk-menu-link"><span class="nk-menu-text"><em class="icon ni ni-wallet-out"></em> Detail Order</span></a>
                                        </li>
                                    <?php endif; ?>    
                                    <?php if(session()->get('administrator')['level'] == 'koki') : ?>
                                        <li class="nk-menu-item">
                                            <a href="<?= base_url('/admin/orderdetail') ?>" class="nk-menu-link"><span class="nk-menu-text"><em class="icon ni ni-wallet-out"></em> Detail Order</span></a>
                                        </li>
                                    <?php endif; ?>    
                                    </ul><!-- .nk-menu-sub -->
                                </li><!-- .nk-menu-item -->
                                
                               
                                
                                </li>
                            </ul><!-- .nk-menu -->
                        </div><!-- .nk-sidebar-menu -->
                    </div><!-- .nk-sidebar-content -->
                </div><!-- .nk-sidebar-element -->
            </div>
            <!-- sidebar @e -->
            <!-- wrap @s -->
            <div class="nk-wrap ">
                <!-- main header @s -->
                <div class="nk-header nk-header-fixed is-light">
                    <div class="container-fluid">
                        <div class="nk-header-wrap">
                            <div class="nk-menu-trigger d-xl-none ml-n1">
                                <a href="#" class="nk-nav-toggle nk-quick-nav-icon" data-target="sidebarMenu"><em class="icon ni ni-menu"></em></a>
                            </div>
                            <div class="nk-header-brand d-xl-none">
                                <a href="html/crypto/index.html" class="logo-link">
                                    <img class="logo-light logo-img" src="<?= base_url() ?>/src/images/logo.png" srcset="./images/logo2x.png 2x" alt="logo">
                                    <img class="logo-dark logo-img" src="<?= base_url() ?>/src/images/logo-dark.png" srcset="./images/logo-dark2x.png 2x" alt="logo-dark">
                                    <span class="nio-version">General</span>
                                </a>
                            </div><!-- .nk-header-brand -->
                            <div class="nk-header-news d-none d-xl-block">
                                <div class="nk-news-list">
                                    <a class="nk-news-item" href="#">
                                        <div class="">
                                            <p>Oneresto | <span>Administrator</span></p>
                                        </div>
                                    </a>
                                </div>
                            </div><!-- .nk-header-news -->
                            <div class="nk-header-tools">
                                <ul class="nk-quick-nav">
                                    <li class="dropdown user-dropdown">
                                        <a href="#" class="dropdown-toggle">
                                            <div class="user-toggle">
                                                <div class="user-avatar sm">
                                                    <em class="icon ni ni-user-alt"></em>
                                                </div>
                                                <div class="user-info d-none d-md-block">
                                                    <div class="user-name"><?php if(!empty(session()->get('administrator'))){ echo session()->get('administrator')['email']; } ?> (<small><?php if(!empty(session()->get('administrator'))){ echo session()->get('administrator')['level']; } ?></small>)</div>
                                                </div>
                                            </div>
                                        </a>
                                    </li><!-- .dropdown -->
                                    <li class="dropdown notification-dropdown mr-n1">
                                        <a onclick="modalProses()" href="<?= base_url() ?>/admin/login/logout" class="dropdown-toggle nk-quick-nav-icon">
                                          <em class="icon ni ni-signout"></em>
                                        </a>
                                    </li><!-- .dropdown -->
                                </ul><!-- .nk-quick-nav -->
                            </div><!-- .nk-header-tools -->
                        </div><!-- .nk-header-wrap -->
                    </div><!-- .container-fliud -->
                </div>
                <!-- main header @e -->
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <?= $this->renderSection('content') ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade" tabindex="-1" id="modal-proses">
                    <div class="modal-dialog modal-sm modal-dialog-top" role="document">
                        <div class="modal-content">
                            <div class="modal-body">
                                <div class="d-flex align-items-center">
                                    <strong>Loading...</strong>
                                    <div class="spinner-border ml-auto" role="status" aria-hidden="true"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade" tabindex="-1" id="modal-berhasil">
                    <div class="modal-dialog modal-sm modal-dialog-top" role="document">
                        <div class="modal-content">
                            <div class="modal-body">
                                <div class="d-flex align-items-center">
                                    <strong>Berhasil</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <!-- content @e -->
                <!-- footer @s -->
                <div class="nk-footer">
                    <div class="container-fluid">
                        <div class="nk-footer-wrap">
                            <div class="nk-footer-copyright"> &copy; 2020, All Right Reserved
                            </div>
                            <div class="nk-footer-links">
                                <ul class="nav nav-sm">
                                    <li class="nav-item"><a class="nav-link" href="#">Version : 1.0</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- footer @e -->
            </div>
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->
    <!-- JavaScript -->
    
    <script src="<?php echo base_url('public/assets/js/app.js') ?>"></script>
    <script>
        function reload() {
            window.location.reload();
        }
        
        function modalProses(){
          $("#modal-proses").modal('show');
        }
        function modalBerhasil(){
          $("#modal-berhasil").modal('show');
        }
    </script>
</body>

</html>