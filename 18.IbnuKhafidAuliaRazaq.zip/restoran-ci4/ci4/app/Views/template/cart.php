
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>OneResto | Cart</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link rel="shortcut icon" href="<?= base_url() ?>/assets/img/logo-resto.png">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link rel="stylesheet" href="<?= base_url() ?>/src/assets/css/dashlite.css?ver=1.6.0">
    <link id="skin-default" rel="stylesheet" href="<?= base_url() ?>/src/assets/css/theme.css?ver=1.6.0"> 

    <script src="<?php echo base_url('/assets/js/bundle.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/js/scripts.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/jquery.dataTables.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/dataTables.bootstrap4.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/dataTables.responsive.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/responsive.bootstrap4.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/js/example-sweetalert.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/ckeditor/ckeditor.js') ?>"></script>
    <script src="<?php echo base_url('/assets/ckeditor/adapters/jquery.js') ?>"></script>

  <link rel="stylesheet" href="<?= base_url() ?>/src/assets/css/dashlite.css?ver=1.6.0">
  <link id="skin-default" rel="stylesheet" href="<?= base_url() ?>/src/assets/css/theme.css?ver=1.6.0"> 
  <link href="<?= base_url() ?>/assets-front/vendor/aos/aos.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets-front/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets-front/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets-front/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets-front/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets-front/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->

  <link href="<?= base_url() ?>/assets-front/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: BizLand - v3.1.0
  * Template URL: https://bootstrapmade.com/bizland-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="<?= base_url() ?>">OneResto<span>.</span></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="<?= base_url() ?>/assets-front/img/logo.png" alt=""></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><?php if(!empty(session('pelanggan')['email'])){ echo '<a class="nav-link scrollto" href="#"><em class="icon ni ni-user-circle"></em> : '.session('pelanggan')['email'].'</a>' ;}else{ echo '<a class="nav-link scrollto" href="'.base_url().'/front/login">Login</a>'; }  ?></a></li>
          <li><a class="nav-link scrollto" href="<?= base_url() ?>/front/login/logout"><em class="icon ni ni-signout"></em>Log-out</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
    <div class="container" style="margin-top: 100px;" data-aos="zoom-out" data-aos-delay="100">
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10">
                <div class="card card-bordered">
                    <div class="card-header font-weight-bold">Daftar Pesanan Anda</div>
                        <div class="card-body">
                            <?php $jumlah_cart = 0; foreach($cart as $jml){ $jumlah_cart = $jumlah_cart + $jml['qty']; }
                              if($jumlah_cart == 0) { ?>
                                  <div class="alert alert-danger alert-icon alert-dismissible">
                                      <strong>Anda Belom Memilih Menu</strong>! Silahkan Pilih Menu Terlebih Dahulu. <a href="<?= base_url() ?>/front/menu/select">Disini!</a><button class="close" data-dismiss="alert"></button>
                                  </div>
                              <?php }else{ ?>
                            <table class="table table-bordered">
                                <tr>
                                    <th>Gambar</th>
                                    <th>Produk</th>
                                    <th>Harga</th>
                                    <th>Jumlah</th>
                                    <th>Total</th>
                                    <th>Hapus</th>
                                </tr>
                                <?php foreach($cart as $cart) :  ?>
                                    <tr>
                                        <td><img style="width:100px; height:75px;" src="<?= base_url() ?>/uploads/<?= $cart['gambar'] ?>" alt="" srcset=""></td>
                                        <td><?= $cart['name'] ?></td>
                                        <td>Rp.<?= number_format($cart['price']) ?></td>
                                        <td>
                                            
                                        <a href="<?= base_url() ?>/front/cart/minus/<?= $cart['qty'] ?>/<?= $cart['rowid'] ?>"><em class="icon ni ni-minus-circle-fill"></em></a>

                                            <?= $cart['qty'] ?>
                                            <a href="<?= base_url() ?>/front/cart/plus/<?= $cart['qty'] ?>/<?= $cart['rowid'] ?>"><em class="icon ni ni-plus-circle-fill"></em></a>
                                        </td>
                                        <td>Rp.<?= number_format($cart['subtotal']) ?></td>
                                        <td><a class="btn btn-sm btn-danger" href="<?= base_url() ?>/front/cart/hapus/<?= $cart['rowid'] ?>"><em class="icon ni ni-trash-fill"></em></a></td>
                                    </tr>
                                <?php endforeach; ?>
                                <tr>
                                    <td class="text-right" colspan="4"><b>Total : </b></td>
                                    <td><b class="text-danger">Rp.<?= number_format($total) ?></b></td>
                                    <td><button type="button" class="btn btn-sm btn-warning mb-2" data-toggle="modal" data-target="#modalTambah">
                                             Checkout
                                        </button></td>
                                </tr>
                            </table>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-1"></div>
        </div>
    </div>  

    <div class="modal fade" tabindex="-1" id="modalTambah">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                <em class="icon ni ni-cross"></em>
            </a>
            <form action="<?php echo base_url().'/front/cart/checkout'; ?>" method="post">
                <div class="modal-header">
                    <h5 class="modal-title">Pilihan Anda</h5>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <input class="form-control" type="text" disabled value="<?= $meja['meja'] ?>">
                        <input type="hidden" name="pilih-meja" disabled value="<?= $meja['idmeja'] ?>">
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <a href="#" class="btn btn-danger" data-dismiss="modal" aria-label="Close">Batal</a>
                    <button onclick="modalProses()" type="submit" id="tambah-simpan" class="btn btn-primary">Lanjutkan!</button>
                </div>
            </form>
        </div>
    </div>
</div>



    

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>OneResto<span>.</span></h3>
            <p>
             Jl. Bibis Bunder <br>
              Krian<br>
              Sidoarjo <br><br>
              <strong>Phone:</strong> +62895335602756<br>
              <strong>Email:</strong> oneresto@company.co.id<br>
            </p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Policy</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Social Media Kami</h4>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container py-4">
      <div class="copyright">
        &copy; Copyright <strong><span>OneResto</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/bizland-bootstrap-business-template/ -->
        Designed by <a href="https://bootstrapmade.com/">IbnuKhafid</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?= base_url() ?>/assets-front/vendor/aos/aos.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/php-email-form/validate.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/purecounter/purecounter.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/waypoints/noframework.waypoints.js"></script>

  <!-- Template Main JS File -->
  <script src="<?= base_url() ?>/assets-front/js/main.js"></script>

</body>

</html>