<?= $this->extend('template/admin') ?>

<?= $this->section('content') ?>
<h2>Menu</h2><hr>

<div class="nk-block">
    <div class="row">
        <div class="col">
            <div class="card card-bordered">
            <form action="<?php echo base_url().'/admin/menu/update'; ?>" method="post" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title">Edit data menu</h5>
                </div>
                <div class="modal-body">
                    <div class="mb-2" id="form-pesan"><?= session()->getFlashdata('info') ?></div>
                    <div class="form-group">
                        <div class="form-control-wrap"> 
                            <select name="idkategori" id="idkategori" class="form-control">
                                <?php foreach($kategori as $key) : ?>
                                    <option <?php if ($key['idkategori'] == $menu['idkategori']) echo "selected" ?> value="<?= $key['idkategori'] ?>" data-id="<?= $key['kategori'] ?>"><?= $key['kategori'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Nama Menu</label>
                        <div class="form-control-wrap">
                            <input type="hidden" name="edit-id" id="edit-id">
                            <input type="text" value="<?= $menu['menu'] ?>" class="form-control" name="edit-menu" id="edit-menu"
                                placeholder="Ubah nama menu">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Gambar</label>
                        <div class="form-control-wrap">
                            <input type="file" class="form-control" name="edit-gambar" id="edit-gambar"
                                placeholder="Ubah Gambar menu">
                        </div>
                    </div>

                    <input type="hidden" class="form-control" value="<?= $menu['gambar'] ?>" name="gambar" id="gambar">
                    <input type="hidden" class="form-control" value="<?= $menu['idmenu'] ?>" name="idmenu" id="idmenu">

                    <div class="form-group">
                        <label class="form-label">Harga</label>
                        <div class="form-control-wrap">
                            <input type="number" value="<?= $menu['harga'] ?>" class="form-control" name="edit-harga" id="edit-harga"
                                placeholder="Ubah keterangan kategori">
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <a href="<?= base_url() ?>/admin/menu" class="btn btn-danger">Batal</a>
                    <button onclick="modalProses()" type="submit" class="btn btn-primary">Tambah</button>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>


<?= $this->endSection() ?>