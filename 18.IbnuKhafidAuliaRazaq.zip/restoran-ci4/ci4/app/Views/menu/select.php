<?= $this->extend('template/admin') ?>

<?= $this->section('content') ?>
<h2>Menu</h2><hr>

<div id="pilih-topik-soal" class="nk-block">
    <!-- card view tambah soal-->
    <div class="card card-bordered card-preview">
        <div class="card-header"><b>Pilih Kategori Pada Menu</b></div>
        <div class="card-body">
            <div class="row">
                <div class="col">
                    <form action="<?= base_url() ?>/admin/menu/read" method="get">
                        <div class="form-group">
                            <div class="form-control-wrap"> 
                                <select name="idkategori" onchange="this.form.submit()" id="idkategori" class="form-control">
                                    <option value="0" >Semua</option>
                                    <?php foreach($kategori as $key) : ?>
                                        <option value="<?= $key['idkategori'] ?>" data-id="<?= $key['kategori'] ?>"><?= $key['kategori'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="nk-block">
    <div class="row">
        <div class="col">
             <div class="card card-bordered">
                    <div class="card-header font-weight-bold">Daftar Menu</div>
                    <div class="card-body">
                        <?= session()->getFlashdata('info') ?>
                        <?= session()->getFlashdata('info-status') ?>
                        <button type="button" class="btn btn-sm btn-primary mb-2" data-toggle="modal" data-target="#modalTambah">
                            <i class="fas fa-plus"></i> Tambah Menu
                        </button>
                        <table id="tblkategori" class="datatable-init table table-bordered">
                        <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Nama Menu</th>
                                    <th>Gambar</th>
                                    <th>Harga</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="data-user">
                                <?php $no = 1; foreach($menu as $menu) : ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= $menu['menu'] ?></td>
                                    <td><img style="width:150px;" src="<?= base_url().'/uploads/'.$menu['gambar'] ?>" alt="" srcset=""></td>
                                    <td><?= 'Rp.'.number_format($menu['harga']) ?></td>
                                    <td>
                                        <form action="<?= base_url() ?>/admin/menu/update_status/<?= $menu['idmenu'] ?>" method="post">
                                            <div class="form-group">
                                                <div class="form-control-wrap"> 
                                                    <select name="status-menu" onchange="this.form.submit()" class="form-control"> 
                                                        <option <?php if ($menu['aktif'] == 1) echo "selected" ?> value="1" >Tersedia</option>
                                                        <option <?php if ($menu['aktif'] == 0) echo "selected" ?> value="0" >Habis</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </form>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?= base_url() ?>/admin/menu/form/<?= $menu['idmenu'] ?>" class="btn btn-sm btn-light"><em class="icon ni ni-edit-alt-fill"></em> Edit</a>
                                            <button onclick="modalHapus(<?= $menu['idmenu'] ?>)" class="btn btn-sm btn-danger"><em class="icon ni ni-trash-fill"></em> Hapus</button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" id="modalTambah">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                <em class="icon ni ni-cross"></em>
            </a>
            <form action="<?php echo base_url().'/admin/menu/insert'; ?>" method="post" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Menu</h5>
                </div>
                <div class="modal-body">
                    <div id="form-pesan-tambah"></div>

                    <div class="form-group">
                        <label>Nama Menu</label>
                        <input required type="text" class="form-control" id="tambah-menu" name="tambah-menu" placeholder="contoh : soto">
                    </div>

                    <div class="form-group">
                        <div class="form-control-wrap"> 
                            <select name="idkategori" id="idkategori" class="form-control">
                                <?php foreach($kategori as $key) : ?>
                                    <option value="<?= $key['idkategori'] ?>" data-id="<?= $key['kategori'] ?>"><?= $key['kategori'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Gambar Menu</label>
                        <input required type="file" class="form-control" id="tambah-gambar" name="tambah-gambar">
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input required type="text" class="form-control" id="tambah-harga" name="tambah-harga" placeholder="contoh : 10000">
                    </div>
                    
                </div>
                <div class="modal-footer bg-light">
                    <a href="#" class="btn btn-danger" data-dismiss="modal" aria-label="Close">Batal</a>
                    <button type="submit" onclick="modalProses()" id="tambah-simpan" class="btn btn-primary">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" id="modal-hapus">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                <em class="icon ni ni-cross"></em>
            </a>
            <div class="modal-header">
                <h5 class="modal-title">Anda Yakin Ingin Menghapus menu?</h5>
            </div>
            <div class="modal-body">
                <div id="form-pesan-edit"></div>
                <div class="form-group">
                    <div class="form-control-wrap">
                        <p>Anda Yakin Menghapus Permanen menu Ini?</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <a id="hapus" onclick="modalProses()" class="btn btn-success">Ya!</a>
            </div>
        </div>
    </div>
</div>

<script>
function modalHapus(id){
    $('#modal-hapus').modal('show');
    $('#hapus').attr('href', '<?= base_url() ?>/admin/menu/hapus/'+id+'');
}
function modalEdit(id){
    $("#modal-edit").modal('show');
    $.getJSON('<?php echo base_url() ?>/admin/kategori/get_id/' + id + '', function (data) {
        if (data.data == 1) {
            $('#edit-id').val(data.idkategori);
            $('#edit-kategori').val(data.kategori);
            $('#edit-keterangan').val(data.keterangan);
        }
    });
}



</script>



<?= $this->endSection() ?>