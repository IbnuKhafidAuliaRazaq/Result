<?= $this->extend('template/admin') ?>

<?= $this->section('content') ?>
<h2>Detail Order</h2><hr>

<div class="nk-block">
    <div class="row">
        <div class="col">
            <div class="card card-bordered">
                <div class="card-header font-weight-bold">Cari Detail Order Berdasarkan Tanggal</div>
                <form action="<?php echo base_url().'/admin/orderdetail/cari'; ?>" method="post">
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>Awal</label>
                                <input required type="date" class="form-control" name="awal">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Sampai</label>
                                <input required type="date" class="form-control" name="sampai">
                            </div>
                        </div>
                    </div>
                        
                </div>
                <div class="card-footer">
                    <div>
                        <button type="submit" id="tambah-simpan" class="btn btn-primary">Simpan</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="row">
        <div class="col">
             <div class="card card-bordered">
                    <div class="card-header font-weight-bold">Daftar Detai Order </div>
                    <div class="card-body">
                        <?= session()->getFlashdata('info-orderdetail') ?>
                        <table id="tableuser" class="datatable-init table table-bordered">
                        <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Tanggal</th>
                                    <th>Menu</th>
                                    <th>Harga</th>
                                    <th>Jumlah</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody id="data-user">
                                <?php $no = 1; foreach($orderdetail as $orderdetail) : ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= $orderdetail['tglorder'] ?></td>
                                    <td><?= $orderdetail['menu'] ?></td>
                                    <td>Rp.<?= number_format($orderdetail['harga']) ?></td>
                                    <td><?= $orderdetail['jumlah'] ?></td>
                                    <td>Rp.<?= number_format($orderdetail['jumlah'] * $orderdetail['harga']) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
            </div>
        </div>
    </div>
</div>


<script>
function modalHapus(id){
    $('#modal-hapus').modal('show');
    $('#hapus').attr('href', '<?= base_url() ?>/admin/orderdetail/hapus/'+id+'');
}
function modalEdit(id){
    $("#modal-edit").modal('show');
    $.getJSON('<?php echo base_url() ?>/admin/orderdetail/get_id/' + id + '', function (data) {
        if (data.data == 1) {
            $('#edit-id').val(data.idorderdetail);
            $('#edit-orderdetail').val(data.orderdetail);
            $('#edit-keterangan').val(data.keterangan);
        }
    });
}
</script>



<?= $this->endSection() ?>