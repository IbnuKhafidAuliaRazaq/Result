<?= $this->extend('template/admin') ?>

<?= $this->section('content') ?>
<h2>Pembayaran</h2><hr>

<div class="nk-block">
    <div class="row">
        <div class="col">
            <div class="card card-bordered">
                <div class="modal-header">
                    <h5 class="modal-title">Kasir Pembayaran</h5>
                </div>
                <div class="modal-body">
                    <div class="mb-2" id="form-pesan"><?= session()->getFlashdata('info-bayar') ?></div>
                    <div class="form-group">
                        <label class="form-label text-primary">Nama Pelanggan : <?= $order['pelanggan'] ?></label><br>
                        <label class="form-label text-primary">Faktur : 000<?= $order['idorder'] ?></label><br>
                        <label class="form-label text-primary">Tanggal : <?= date('d-m-Y',strtotime($order['tglorder'])) ?></label>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Rincian Pesanan</label>
                        <table class="datatable-init table table-bordered">
                            <tr>
                                <th>No.</th>
                                <th>Menu</th>
                                <th>Harga</th>
                                <th>Jumlah</th>
                                <th>Total</th>
                            </tr>
                            <?php $no=1; foreach($orderdetail as $detail) : ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $detail['menu'] ?></td>
                                <td>Rp.<?= number_format($detail['hargajual']) ?></td>
                                <td><?= $detail['jumlah'] ?></td>
                                <td>Rp.<?= number_format($detail['jumlah'] * $detail['hargajual']) ?></td>
                            </tr>
                            <?php endforeach ?></tr>
                        </table>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Total Keseluruhan Item</label>
                        <div class="form-control-wrap">
                            <input readonly type="text" value="Rp.<?= number_format($order['total']) ?>" class="form-control" >
                            <input readonly type="hidden" value="<?= $order['total'] ?>" id="input-total" class="form-control" name="total">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Bayar</label>
                        <div class="form-control-wrap">
                            <input required type="number" onkeyup="bayar_benar()" class="form-control" id="input-bayar" name="bayar">
                            <input required hidden type="number" class="form-control" value="<?= $order['idorder'] ?>" name="idorder">
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <a href="<?= base_url() ?>/admin/order" class="btn btn-danger">Batal</a>
                    <button disabled onclick="modalEdit()" id="btn-bayar" class="btn btn-primary">Bayar</button>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" tabindex="-1" id="modal-edit">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                <em class="icon ni ni-cross"></em>
            </a>
            <form action="<?php echo base_url().'/admin/order/bayar'; ?>" method="post">
                <div class="modal-header">
                    <h5 class="modal-title">Konfirmasi Pembayaran</h5>
                </div>
                <div class="modal-body">
                    <div id="form-pesan-edit"></div>
                    <div class="form-group">
                        <label class="form-label">Total</label>
                        <div class="form-control-wrap">
                            <input type="hidden" name="bayar-id-order" value="<?= $order['idorder'] ?>">
                            <input readonly type="text" value="<?= $order['total'] ?>" class="form-control" name="bayar-total" id="bayar-total">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Bayar</label>
                        <div class="form-control-wrap">
                            <input readonly type="text" class="form-control" name="bayar-bayar" id="bayar-bayar">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Kembali</label>
                        <div class="form-control-wrap">
                            <input readonly type="text" class="form-control" name="bayar-kembali" id="bayar-kembali">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="alert alert-primary" role="alert">
                            Pastikan Semua Data <b>Benar</b> Terlebih Dahulu!
                        </div>
                    </div>
                    
                </div>
                <div class="modal-footer bg-light">
                    <button onclick="modalProses()" type="submit" id="edit-simpan" class="btn btn-primary">Konfirmasi</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
function bayar_benar(){
    let bayar = parseInt($('#input-bayar').val());
    let total = parseInt($('#input-total').val());
    if( bayar >= total ){
        $('#btn-bayar').removeAttr('disabled');
    }else{
        $('#btn-bayar').attr('disabled', 'true');
    }
}
function modalEdit(id){
    $("#modal-edit").modal('show');
    let bayar = parseInt($('#input-bayar').val());
    let total = parseInt($('#input-total').val());

    $('#bayar-bayar').val(bayar);
    $('#bayar-kembali').val(bayar - total);
}



</script>

<?= $this->endSection() ?>