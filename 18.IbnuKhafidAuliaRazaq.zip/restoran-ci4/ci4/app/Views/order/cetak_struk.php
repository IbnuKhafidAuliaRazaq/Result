<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div style="margin-top: 20px; margin-left: 100px;" class="container">
    <div class="row">
        <div class="well col-xs-10 col-sm-10 col-md-6 col-xs-offset-1 col-sm-offset-1 col-md-offset-3">
            <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6">
                    <address>
                        <strong>ONERESTO!</strong>
                        <br>
                        Jl. Bibis Bunder, RT.08, RW.02
                        <br>
                        Krian, Sidoarjo, Kode Pos = 61262
                        <br>
                        <abbr title="Phone">Telepon :</abbr> +62 895-3356-02756
                    </address>
                </div>
                <div class="col-xs-6 col-sm-6 col-md-6 text-right">
                    <p>
                        <em>Tanggal : <?= $struk[0]['tglorder'] ?></em>
                    </p>
                    <p>
                        <em>Nama Pelanggan : <?= $struk[0]['pelanggan'] ?></em>
                    </p>
                    <p>
                        <em>Faktur : 000<?= $struk[0]['idorder'] ?></em>
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="text-center">
                    <h1>Struk Pembayaran</h1>
                </div>
                </span>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>qty</th>
                            <th class="text-center">Harga</th>
                            <th class="text-center">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($struk as $value) : ?>
                            <tr>
                                <td><?= $value['menu'] ?></td>
                                <td><?= $value['jumlah'] ?></td>
                                <td>Rp.<?= number_format($value['harga']) ?></td>
                                <td>Rp.<?= number_format($value['harga'] * $value['jumlah']) ?></td>
                            </tr>
                        <?php endforeach ?>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <tr>
                            <td>   </td>
                            <td>   </td>
                            <td class="text-right">
                            <p>
                                <strong>Subtotal: </strong>
                            </p>
                            </td>
                            <td class="text-center">
                            <p>
                                <strong>Rp.<?= number_format($struk[0]['total']) ?></strong>
                            </p></td>
                        </tr>
                        <tr>
                            <td>   </td>
                            <td>   </td>
                            <td class="text-right"><h4><strong>Total: </strong></h4></td>
                            <td class="text-center text-danger"><h4><strong>Rp.<?= number_format($struk[0]['total']) ?></strong></h4></td>
                        </tr>
                    </tbody>
                </table></td>
            </div>
        </div>
    </div>


    <script>
        window.print();
    </script>