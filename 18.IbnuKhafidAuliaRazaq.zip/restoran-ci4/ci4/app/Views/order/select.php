<?= $this->extend('template/admin') ?>

<?= $this->section('content') ?>
<h2>Order</h2><hr>

<div class="nk-block">
    <div class="row">
        <div class="col">
             <div class="card card-bordered">
                    <div class="card-header font-weight-bold">Daftar order </div>
                    <div class="card-body">
                        <table id="tableuser" class="datatable-init table table-bordered">
                        <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Faktur</th>
                                    <th>Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="data-user">
                                <?php $no = 1; foreach($order as $order) : ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td>000<?= $order['idorder'] ?></td>
                                    <td><?= 'Rp.'.number_format($order['total']) ?></td>
                                    <td>
                                        <?php 
                                            if($order['status'] == 0){
                                                echo '<a href="'.base_url().'/admin/order/pembayaran/'.$order['idorder'].'" class="btn btn-sm btn-danger"><em class="icon mr-1 ni ni-sign-idr-alt"></em>Bayar</a>';
                                            }else{
                                                echo '<button class="btn btn-sm btn-success"><em class="icon mr-1 ni ni-check-fill-c"></em>Lunas</button>';
                                            }
                                        
                                        ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" id="modal-hapus">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                <em class="icon ni ni-cross"></em>
            </a>
            <div class="modal-header">
                <h5 class="modal-title">Anda Yakin Ingin Menghapus topik?</h5>
            </div>
            <div class="modal-body">
                <div id="form-pesan-edit"></div>
                <div class="form-group">
                    <div class="form-control-wrap">
                        <p>Anda Yakin Menghapus Permanen order Ini?</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <a id="hapus" onclick="modalProses()" class="btn btn-success">Ya!</a>
            </div>
        </div>
    </div>
</div>

<script>
function modalHapus(id){
    $('#modal-hapus').modal('show');
    $('#hapus').attr('href', '<?= base_url() ?>/admin/order/hapus/'+id+'');
}
</script>



<?= $this->endSection() ?>