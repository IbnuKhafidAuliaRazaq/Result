<?= $this->extend('template/admin') ?>

<?= $this->section('content') ?>
<h2>User-Admin</h2><hr>

<div class="nk-block">
    <div class="row">
        <div class="col">
             <div class="card card-bordered">
                    <div class="card-header font-weight-bold">Daftar user <input id='filterInput' onkeyup='filterTable()' type='hidden'></div>
                    <div class="card-body">
                        <?= session()->getFlashdata('info-user') ?>
                        <button type="button" class="btn btn-sm btn-primary mb-2" data-toggle="modal" data-target="#modalTambah">
                            <em class="icon ni ni-plus-sm"></em> Tambah User
                        </button>
                        <table id="tableuser" class="datatable-init table table-bordered">
                        <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Nama user</th>
                                    <th>Email</th>
                                    <th>Posisi</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="data-user">
                                <?php $no = 1; foreach($user as $user) : ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= $user['user'] ?></td>
                                    <td><?= $user['email'] ?> <small style="cursor:pointer;"onclick="modalEdit(<?= $user['iduser'] ?>)"><em class="icon ni ni-pen2"></em></small></td>
                                    <?php if($user['aktif'] == 1){ $aktif = '<a href="'.base_url().'/admin/user/update/'.$user['iduser'].'/0" style="width:70px" class="btn text-center btn-sm btn-primary">Aktif</a>'; }else{ $aktif = '<a href="'.base_url().'/admin/user/update/'.$user['iduser'].'/1" style="width:70px" class="btn text-center btn-sm btn-danger">Banned</a>';}?>
                                    <td>
                                    <form action="<?= base_url() ?>/admin/user/ubah_level/<?= $user['iduser'] ?>" method="post">
                                        <div class="form-group">
                                            <div class="form-control-wrap"> 
                                                <select name="ubah-level" onchange="this.form.submit()" id="idkategori" class="form-control">
                                                    <option <?php if($user['level']=='admin') echo 'selected' ?> value="admin" >Admin</option>
                                                    <option <?php if($user['level']=='kasir') echo 'selected' ?> value="kasir" >Kasir</option>
                                                    <option <?php if($user['level']=='koki') echo 'selected' ?> value="koki" >Koki</option>
                                                </select>
                                            </div>
                                        </div>
                                    </form>
                                    </td>
                                    <td><?= $aktif ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <button onclick="modalEdit(<?= $user['iduser'] ?>)" class="btn btn-sm btn-light"><em class="icon ni ni-edit-alt-fill"></em> Edit</button>
                                            <button onclick="modalHapus(<?= $user['iduser'] ?>)" class="btn btn-sm btn-danger"><em class="icon ni ni-trash-fill"></em> Hapus</button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" id="modalTambah">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                <em class="icon ni ni-cross"></em>
            </a>
            <form action="<?php echo base_url().'/admin/user/insert'; ?>" method="post">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah User</h5>
                </div>
                <div class="modal-body">
                    <div id="form-pesan-tambah"></div>

                    <div class="form-group">
                        <label>Nama user</label>
                        <input required type="text" class="form-control" id="tambah-user" name="tambah-user">
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <input required type="email" class="form-control" id="tambah-email" name="tambah-email">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input required type="password" class="form-control" id="tambah-password" name="tambah-password">
                    </div>
                    <div class="form-group">
                        <label>Konfirmasi Password</label>
                        <input required type="password" class="form-control" id="tambah-konfirmasi" name="tambah-konfirmasi">
                    </div>
                    <div class="form-group">
                        <label>Level</label>
                            <div class="form-control-wrap"> 
                                <select name="tambah-level" id="tambah-level" class="form-control">
                                    <option value="admin">Admin</option>
                                    <option value="kasir">Kasir</option>
                                    <option value="koki">Koki</option>
                                </select>
                            </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <a href="#" class="btn btn-danger" data-dismiss="modal" aria-label="Close">Batal</a>
                    <button type="submit" id="tambah-simpan" class="btn btn-primary">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" tabindex="-1" id="modal-edit">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                <em class="icon ni ni-cross"></em>
            </a>
            <form action="<?php echo base_url().'/admin/user/ubah_email'; ?>" method="post">
                <div class="modal-header">
                    <h5 class="modal-title">Ubah Email</h5>
                </div>
                <div class="modal-body">
                    <div id="form-pesan-edit"></div>
                    <div class="form-group">
                        <label class="form-label">Nama user</label>
                        <div class="form-control-wrap">
                            <input type="hidden" name="edit-email-id" id="edit-id">
                            <input readonly type="text" class="form-control" name="edit-user" id="edit-user">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email</label>
                        <div class="form-control-wrap">
                            <input type="email" class="form-control" name="edit-email" id="edit-email">
                        </div>
                    </div>
                    
                </div>
                <div class="modal-footer bg-light">
                    <button type="submit" id="edit-simpan" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" tabindex="-1" id="modal-hapus">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                <em class="icon ni ni-cross"></em>
            </a>
            <div class="modal-header">
                <h5 class="modal-title">Anda Yakin Ingin Menghapus User?</h5>
            </div>
            <div class="modal-body">
                <div id="form-pesan-edit"></div>
                <div class="form-group">
                    <div class="form-control-wrap">
                        <p>Anda Yakin Menghapus Permanen user Ini?</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <a id="hapus" onclick="modalProses()" class="btn btn-success">Ya!</a>
            </div>
        </div>
    </div>
</div>

<script>
function modalHapus(id){
    $('#modal-hapus').modal('show');
    $('#hapus').attr('href', '<?= base_url() ?>/admin/user/hapus/'+id+'');
}
function modalEdit(id){
    $("#modal-edit").modal('show');
    $.getJSON('<?php echo base_url() ?>/admin/user/get_id/' + id + '', function (data) {
        if (data.data == 1) {
            $('#edit-id').val(data.iduser);
            $('#edit-user').val(data.user);
            $('#edit-email').val(data.email);
        }
    });
}
</script>



<?= $this->endSection() ?>