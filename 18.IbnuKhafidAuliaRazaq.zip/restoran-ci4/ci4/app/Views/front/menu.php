
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>OneResto | Home</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link rel="shortcut icon" href="<?= base_url() ?>/assets/img/logo-resto.png">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files --><link rel="stylesheet" href="<?= base_url() ?>/src/assets/css/dashlite.css?ver=1.6.0">
    <link id="skin-default" rel="stylesheet" href="<?= base_url() ?>/src/assets/css/theme.css?ver=1.6.0"> 

<script src="<?php echo base_url('/assets/js/bundle.js?ver=1.6.0') ?>"></script>
<script src="<?php echo base_url('/assets/js/scripts.js?ver=1.6.0') ?>"></script>
<script src="<?php echo base_url('/assets/datatable/js/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('/assets/datatable/js/dataTables.bootstrap4.min.js') ?>"></script>
<script src="<?php echo base_url('/assets/datatable/js/dataTables.responsive.min.js') ?>"></script>
<script src="<?php echo base_url('/assets/datatable/js/responsive.bootstrap4.min.js') ?>"></script>
<script src="<?php echo base_url('/assets/js/example-sweetalert.js?ver=1.6.0') ?>"></script>
<script src="<?php echo base_url('/assets/ckeditor/ckeditor.js') ?>"></script>
<script src="<?php echo base_url('/assets/ckeditor/adapters/jquery.js') ?>"></script>
  <link rel="stylesheet" href="<?= base_url() ?>/src/assets/css/dashlite.css?ver=1.6.0">
  <link id="skin-default" rel="stylesheet" href="<?= base_url() ?>/src/assets/css/theme.css?ver=1.6.0"> 
  <link href="<?= base_url() ?>/assets-front/vendor/aos/aos.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets-front/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets-front/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets-front/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets-front/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets-front/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?= base_url() ?>/assets-front/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: BizLand - v3.1.0
  * Template URL: https://bootstrapmade.com/bizland-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="<?= base_url() ?>">OneResto<span>.</span></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="<?= base_url() ?>/assets-front/img/logo.png" alt=""></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <?php $jumlah_cart = 0; foreach($cart as $cart){ $jumlah_cart = $jumlah_cart + $cart['qty']; } ?>
          <?php if(!empty(session('pelanggan'))) { ?>
            <li data-toggle="modal" data-target="#modalTambah"><a style="cursor: pointer;" class="nav-link scrollto"  id="modal-history">History</a></li>
            <li><a class="nav-link scrollto" href="<?= base_url() ?>/front/cart"><em class="icon ni ni-cart-fill"></em> : <?= $jumlah_cart ?></a></li>
            <li><a class="nav-link scrollto" href="<?= base_url() ?>/front/pelanggan/select/<?= session('pelanggan')['idpelanggan'] ?>"><em class="icon ni ni-user-circle"></em> : <?= session('pelanggan')['email'] ?></a></li>
            <li><a class="nav-link scrollto" href="<?= base_url() ?>/front/login/logout"><em class="icon ni ni-signout"></em>Log-out</a></li>
          <?php }else{ ?>
          
          <li><a class="nav-link scrollto" href="<?= base_url() ?>/front/cart"><em class="icon ni ni-cart-fill"></em> : <?= $jumlah_cart ?></a></li>
          <li><a class="nav-link scrollto" href="<?= base_url() ?>/front/login">Login</a></li>
          <?php } ?>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <main id="main">


    <!-- ======= Menu Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Menu</h2>
          <h3>Check our <span>Menu</span></h3>
          <p>Pilih Kategori Dibawah Untuk Memilih Menu</p>
         </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li><a href="<?= base_url() ?>/front/menu/select">All</a></li>
              <?php foreach($kategori as $kategori) : ?>
              <li><a href="<?= base_url() ?>/front/menu/kategori/<?= $kategori['idkategori'] ?>"><?= $kategori['kategori'] ?></a></li>
              <?php endforeach; ?>
            </ul>
          </div>
        </div>

        <div class="row">
        <?php foreach($menu as $menu) : ?>
          <?php if($menu['aktif'] == 0) { ?>
              <div class="col-lg-3 col-md-6 d-flex align-items-stretch mb-4" data-aos="fade-up" data-aos-delay="200">
              <div class="member">
                <div class="member-img">
                  <img style="height: 250px; width: 300px; opacity: 20%;" src="<?= base_url() ?>/uploads/<?= $menu['gambar'] ?>" class="img-fluid" alt="">
                </div>
                <div class="member-info mt-1">
                  <h5><?= $menu['menu'] ?></h5>
                    <div class="btn btn-danger btn-sm">Habis</div>
                  <div class="btn btn-sm btn-secondary"></i>Rp.<?= number_format($menu['harga']) ?></div>
                </div>
              </div>
            </div>
          <?php }else{ ?>
          <div class="col-lg-3 col-md-6 d-flex align-items-stretch mb-4" data-aos="fade-up" data-aos-delay="200">
            <div class="member">
              <div class="member-img bg-primary">
                <img style="height: 250px; width: 300px;" src="<?= base_url() ?>/uploads/<?= $menu['gambar'] ?>" class="img-fluid" alt="">
              </div>
              <div class="member-info mt-1">
                <h5><?= $menu['menu'] ?></h5>
                <?php if(empty(session('pelanggan'))) : ?>
                  <a class="btn btn-sm btn-primary" href="<?= base_url() ?>/front/login""><i class="bi bi-cart"></i> Add To Cart</a>
                <?php endif; ?>
                <?php if(!empty(session('pelanggan'))) : ?>
                  <a class="btn btn-sm btn-primary" href="<?= base_url() ?>/front/cart/addToCart/<?= $menu['idmenu'] ?>"><i class="bi bi-cart"></i> Add To Cart</a>
                <?php endif; ?>
                <div class="btn btn-sm btn-secondary"></i>Rp.<?= number_format($menu['harga']) ?></div>
              </div>
            </div>
          </div>
          <?php } ?>
        <?php endforeach; ?>
        </div>

      </div>
    </section><!-- End Portfolio Section --> 

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Contact</h2>
          <h3><span>Contact Us</span></h3>
          <p>Berikan Pesan Dan Masukan Kepada Restoran Kami Agar Kami Semakin Berkembang!.</p>
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-6">
            <div class="info-box mb-4">
              <i class="bx bx-map"></i>
              <h3>Alamat Kami</h3>
              <p>Jl. Bibis Bunder, RT. 08, RW. 02, Kel. Tambak Kemerakan, Kec. Krian.</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-envelope"></i>
              <h3>Email</h3>
              <p>oneresto@company.co.id</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-phone-call"></i>
              <h3>Telepon</h3>
              <p>+62 895 3356 02756</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>OneResto<span>.</span></h3>
            <p>
             Jl. Bibis Bunder <br>
              Krian<br>
              Sidoarjo <br><br>
              <strong>Phone:</strong> +62895335602756<br>
              <strong>Email:</strong> oneresto@company.co.id<br>
            </p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Policy</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Social Media Kami</h4>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container py-4">
      <div class="copyright">
        &copy; Copyright <strong><span>OneResto</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/bizland-bootstrap-business-template/ -->
        Designed by <a href="https://bootstrapmade.com/">IbnuKhafid</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <div class="modal fade" tabindex="-1" id="modalTambah">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                <em class="icon ni ni-cross"></em>
            </a>
            
                <div class="modal-header">
                    <h5 class="modal-title">History Pembelian</h5>
                </div>
                <div class="modal-body">
                    <table class="table table-bordered">
                      <tr>
                        <th>Tanggal Order</th>
                        <th>Menu</th>
                        <th class="text-center">Harga</th>
                        <th class="text-center">Jumlah</th>
                        <th class="text-center">Total</th>
                      </tr>
                      <?php if(!empty(session('pelanggan'))) { ?>
                      <?php foreach($vorderdetail as $key) : ?>
                        <?php if($key['idpelanggan'] == session('pelanggan')['idpelanggan'] ) : ?>
                        <tr>
                          <td><?= $key['tglorder'] ?></td>
                          <td><?= $key['menu'] ?></td>
                          <td>Rp.<?= number_format($key['hargajual']) ?></td>
                          <td><?= $key['jumlah'] ?></td>
                          <td>Rp.<?= number_format($key['total']) ?></td>
                        </tr>
                        <?php endif; ?>
                      <?php endforeach; ?>
                      <?php } ?>
                    </table>
                </div>
                <div class="modal-footer bg-light">
                    <a href="#" class="btn btn-danger" data-dismiss="modal" aria-label="Close">Tutup</a>
                    
                </div>
           
        </div>
    </div>
</div>
  


  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?= base_url() ?>/assets-front/vendor/aos/aos.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/php-email-form/validate.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/purecounter/purecounter.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="<?= base_url() ?>/assets-front/vendor/waypoints/noframework.waypoints.js"></script>

  <!-- Template Main JS File -->
  <script src="<?= base_url() ?>/assets-front/js/main.js"></script>

</body>

</html>