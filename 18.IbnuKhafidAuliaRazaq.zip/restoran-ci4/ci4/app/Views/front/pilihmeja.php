<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="@@page-discription">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="<?= base_url() ?>/assets/img/logo-resto.png">
    <!-- Page Title  -->
    <title>OneResto | Admin</title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?= base_url() ?>/src/assets/css/dashlite.css?ver=1.6.0">
    <link id="skin-default" rel="stylesheet" href="<?= base_url() ?>/src/assets/css/theme.css?ver=1.6.0"> 
    
    <script src="<?php echo base_url('/assets/js/bundle.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/js/scripts.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/jquery.dataTables.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/dataTables.bootstrap4.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/dataTables.responsive.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/responsive.bootstrap4.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/js/example-sweetalert.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/ckeditor/ckeditor.js') ?>"></script>
    <script src="<?php echo base_url('/assets/ckeditor/adapters/jquery.js') ?>"></script>
</head>

<body class="nk-body bg-lighter npc-general ">

<div class="nk-block nk-block-middle nk-auth-body mt-3">
    <div class="brand-logo pb-5">
        <a href="/demo3/index.html" class="logo-link">
            <img class="logo-img logo-img-lg" src="<?= base_url() ?>/assets/img/logo-dashlite.png" alt="logo">
        </a>
    </div>
    <div class="nk-block-head">
        <div class="nk-block-head-content">
            <h5 class="nk-block-title">Pilih Take Away Atau Dine-In!</h5>
            <div class="nk-block-des">
        </div>
    </div>
    <?= session()->getFlashdata('info-meja') ?>
    
    <form action="<?= base_url() ?>/front/menu" method="post">
    <div class="form-group">
        <div class="form-control-wrap"> 
            <label for="">Take Away Tau Dine-In</label>
            <select name="pilih" onchange="tampilMeja()" id="pilih" class="form-control">
                <option value="0" >Take Away</option>
                <option value="1">Dine-In</option>
            </select>
        </div>
        <input type="hidden" id="idmeja" value="9" name="idmeja">
    </div>
    <div hidden="true" id="meja" class="form-group">
        <div class="form-control-wrap"> 
            <label for="">Pilih Meja</label>
            <select name="pilih-id" onchange="idMeja()" id="pilih-id" class="form-control">
                <option value="0">Pilih</option>
                <?php foreach($meja as $meja) : ?>
                    <?php if($meja['idmeja'] != 9 ) { if($meja['aktif'] == 1 ) { ?>
                        <option value="<?= $meja['idmeja'] ?>"><?= $meja['meja'] ?></option>
                    <?php } } ?>
                <?php endforeach; ?>
            </select>
        </div>
       
    </div>
    <button type="submit" id="tambah-simpan" class="btn btn-primary">Pilih Menu</button>
    </form>
</div>





<script src="<?php echo base_url('public/assets/js/app.js') ?>"></script>
    <script>
        function reload() {
            window.location.reload();
        }
        
        function modalProses(){
          $("#modal-proses").modal('show');
        }
        function modalBerhasil(){
          $("#modal-berhasil").modal('show');
        }
        function tampilMeja(){
          var pilih = $("#pilih").val();
          if(pilih == 1){
            $('#meja').removeAttr('hidden');
            $('#idmeja').val(0);
          }else{
            $('#meja').attr('hidden', 'true');  
            $('#idmeja').val(9);
          }
        }
        function idMeja(){
            var id = $('#pilih-id').val(); 
            $('#idmeja').val(id);
        }
    </script>
</body>

</html>