<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="@@page-discription">
    <!-- Fav Icon  -->
    <!-- Page Title  -->
    <title>OneResto | Registrasi Pelanggan</title>

    <link rel="shortcut icon" href="<?= base_url() ?>/assets/img/logo-resto.png">
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?= base_url() ?>/src/assets/css/dashlite.css?ver=1.6.0">
    <link id="skin-default" rel="stylesheet" href="<?= base_url() ?>/src/assets/css/theme.css?ver=1.6.0"> 
    
    <script src="<?php echo base_url('/assets/js/bundle.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/js/scripts.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/jquery.dataTables.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/dataTables.bootstrap4.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/dataTables.responsive.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/datatable/js/responsive.bootstrap4.min.js') ?>"></script>
    <script src="<?php echo base_url('/assets/js/example-sweetalert.js?ver=1.6.0') ?>"></script>
    <script src="<?php echo base_url('/assets/ckeditor/ckeditor.js') ?>"></script>
    <script src="<?php echo base_url('/assets/ckeditor/adapters/jquery.js') ?>"></script>
</head>

<body class="nk-body bg-lighter npc-general ">

    <div class="nk-block nk-block-middle nk-auth-body mt-3">
        <div class="brand-logo pb-5">
            <a href="/demo3/index.html" class="logo-link">
                <img class="logo-img logo-img-lg" src="<?= base_url() ?>/assets/img/logo-dashlite.png" alt="logo">
            </a>
        </div>
        <div class="nk-block-head">
            <div class="nk-block-head-content">
                <h5 class="nk-block-title">Detail Akun</h5>
                <div class="nk-block-des">
            </div>
        </div>
    </div>
    <form action="<?= base_url() ?>/front/pelanggan/update/<?= $pelanggan['idpelanggan'] ?>" method="post">
        <div class="form-group">
            <div class="form-label-group">
                <label class="form-label" for="default-01">Nama</label>
            </div>
            <input id="ubah" required type="text" name="nama" disabled value="<?= $pelanggan['pelanggan'] ?>" class="form-control form-control-lg" id="default-01" placeholder="Nama">
        </div>
        <div class="form-group">
            <div class="form-label-group">
                <label class="form-label" for="default-01">alamat</label>
            </div>
            <input  id="ubah1"  required type="text" name="alamat"  disabled value="<?= $pelanggan['alamat'] ?>" class="form-control form-control-lg" id="default-01" placeholder="Alamat(Kota)">
        </div>
        <div class="form-group">
            <div class="form-label-group">
                <label class="form-label" for="default-01">Telepon</label>
            </div>
            <input  id="ubah2"  required type="number" name="telepon" class="form-control form-control-lg"  disabled value="<?= $pelanggan['telp'] ?>" id="default-01" placeholder="Telepon">
        </div>
        <div class="form-group">
            <div class="form-label-group">
                <label class="form-label" for="default-01">Email</label>
            </div>
            <input  id="ubah3"  required type="email" name="email" class="form-control form-control-lg" disabled value="<?= $pelanggan['email'] ?>" id="default-01" placeholder="Email">
        </div>
        <div class="form-group">
            <button id="tombol-ubah" hidden="true" class="btn btn-lg btn-primary btn-block">Simpan</button>
        </div>
    </form>
    <button onclick="ubah()" id="ubah-tombol" class="btn btn-lg btn-secondary btn-block">Ubah Data</button>
</div>
        


<script src="<?php echo base_url('public/assets/js/app.js') ?>"></script>
    <script>
        function reload() {
            window.location.reload();
        }
        
        function modalProses(){
          $("#modal-proses").modal('show');
        }
        function modalBerhasil(){
          $("#modal-berhasil").modal('show');
        }
        function ubah(){
            $("#ubah").removeAttr('disabled');
            $("#ubah1").removeAttr('disabled');
            $("#ubah2").removeAttr('disabled');
            $("#ubah3").removeAttr('disabled');
            $("#tombol-ubah").removeAttr('hidden');
            $("#ubah-tombol").attr('hidden', 'true');
        }
        
    </script>
</body>

</html>