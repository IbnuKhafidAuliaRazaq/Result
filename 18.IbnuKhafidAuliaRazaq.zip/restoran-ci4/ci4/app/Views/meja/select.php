<?= $this->extend('template/admin') ?>

<?= $this->section('content') ?>
<h2>Meja</h2><hr>

<div class="nk-block">
    <div class="row">
        <div class="col">
             <div class="card card-bordered">
                    <div class="card-header font-weight-bold">Daftar Meja <input id='filterInput' onkeyup='filterTable()' type='hidden'></div>
                    <div class="card-body">
                        <?= session()->getFlashdata('info-meja') ?>
                        <button type="button" class="btn btn-sm btn-primary mb-2" data-toggle="modal" data-target="#modalTambah">
                            <i class="fas fa-plus"></i> Tambah meja
                        </button>
                        <table id="tableuser" class="datatable-init table table-bordered">
                        <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Nama meja</th>
                                    <th>aktif</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="data-user">
                                <?php $no = 1; foreach($meja as $meja) : ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= $meja['meja'] ?></td>
                                    <td>
                                    <?php if($meja['meja'] != 'Take Away') { ?>
                                        <form action="<?= base_url() ?>/admin/meja/update_status/<?= $meja['idmeja'] ?>" method="post">
                                            <div class="form-group">
                                                <div class="form-control-wrap"> 
                                                    <select name="status-meja" onchange="this.form.submit()" class="form-control"> 
                                                        <option <?php if ($meja['aktif'] == 1) echo "selected" ?> value="1" >Tersedia</option>
                                                        <option <?php if ($meja['aktif'] == 0) echo "selected" ?> value="0" >Penuh</option>
                                                    </select></td></div>
                                            </div>
                                        </form>
                                    <?php }else{ echo '<div class="btn btn-primary btn-sm">Tersedia</div>'; } ?>
                                    <td>
                                        <div class="btn-group">
                                            <button onclick="modalEdit(<?= $meja['idmeja'] ?>)" class="btn btn-sm btn-light"><em class="icon ni ni-edit-alt-fill"></em> Edit</button>
                                            <button onclick="modalHapus(<?= $meja['idmeja'] ?>)" class="btn btn-sm btn-danger"><em class="icon ni ni-trash-fill"></em> Hapus</button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" id="modalTambah">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                <em class="icon ni ni-cross"></em>
            </a>
            <form action="<?php echo base_url().'/admin/meja/insert'; ?>" method="post">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah meja</h5>
                </div>
                <div class="modal-body">
                    <div id="form-pesan-tambah"></div>

                    <div class="form-group">
                        <label>Nama meja</label>
                        <input required type="text" class="form-control" id="tambah-meja" name="tambah-meja" placeholder="contoh : makanan">
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <a href="#" class="btn btn-danger" data-dismiss="modal" aria-label="Close">Batal</a>
                    <button onclick="modalProses()" type="submit" id="tambah-simpan" class="btn btn-primary">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" tabindex="-1" id="modal-edit">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                <em class="icon ni ni-cross"></em>
            </a>
            <form action="<?php echo base_url().'/admin/meja/ubah'; ?>" method="post">
                <div class="modal-header">
                    <h5 class="modal-title">Edit meja</h5>
                </div>
                <div class="modal-body">
                    <div id="form-pesan-edit"></div>
                    <div class="form-group">
                        <label class="form-label">Nama meja</label>
                        <div class="form-control-wrap">
                            <input type="hidden" name="edit-id" id="edit-id">
                            <input type="text" class="form-control" name="edit-meja" id="edit-meja"
                                placeholder="Ubah nama meja">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Keterangan meja</label>
                        <div class="form-control-wrap">
                            <input type="text" class="form-control" name="edit-keterangan" id="edit-keterangan"
                                placeholder="Ubah keterangan meja">
                        </div>
                    </div>
                    
                </div>
                <div class="modal-footer bg-light">
                    <button onclick="modalProses()" type="submit" id="edit-simpan" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" tabindex="-1" id="modal-hapus">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                <em class="icon ni ni-cross"></em>
            </a>
            <div class="modal-header">
                <h5 class="modal-title">Anda Yakin Ingin Menghapus topik?</h5>
            </div>
            <div class="modal-body">
                <div id="form-pesan-edit"></div>
                <div class="form-group">
                    <div class="form-control-wrap">
                        <p>Anda Yakin Menghapus Permanen meja Ini?</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <a id="hapus" onclick="modalProses()" class="btn btn-success">Ya!</a>
            </div>
        </div>
    </div>
</div>

<script>
function modalHapus(id){
    $('#modal-hapus').modal('show');
    $('#hapus').attr('href', '<?= base_url() ?>/admin/meja/hapus/'+id+'');
}
function modalEdit(id){
    $("#modal-edit").modal('show');
    $.getJSON('<?php echo base_url() ?>/admin/meja/get_id/' + id + '', function (data) {
        if (data.data == 1) {
            $('#edit-id').val(data.idmeja);
            $('#edit-meja').val(data.meja);
            $('#edit-keterangan').val(data.keterangan);
        }
    });
}
</script>



<?= $this->endSection() ?>