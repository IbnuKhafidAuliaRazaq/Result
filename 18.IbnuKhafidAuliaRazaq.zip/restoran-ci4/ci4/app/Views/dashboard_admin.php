<?= $this->extend('template/admin') ?>

<?= $this->section('content') ?>

<div class="nk-block">
    <div class="row">
        <div class="col">
            <div class="card card-bordered">
                <img src="<?= base_url() ?>/assets/img/kategori.jpg" class="card-img-top" alt="">
                <div class="card-inner">       
                    <h5 class="card-title"><?= $kategori ?> Kategori Menu</h5>
                    <p class="card-text">Menu Dalam Restoran Ini Dikelompokkan Menjadi <?= $kategori ?> Kategori.</p> 
                </div>
            </div>
            <div class="card card-bordered">
                <img src="<?= base_url() ?>/assets/img/menu.jpg" class="card-img-top" alt="">
                <div class="card-inner">       
                    <h5 class="card-title"><?= $menu ?> Total Menu</h5>
                    <p class="card-text">Restoran Ini Menjajakan <?= $menu ?> Menu.</p>         
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card card-bordered">
                <img src="<?= base_url() ?>/assets/img/order.jpg" class="card-img-top" alt="">
                <div class="card-inner">       
                    <h5 class="card-title"><?= $order ?> Total Order</h5>
                    <p class="card-text">Restoran Ini Telah Melayani <?= $menu ?> Pesanan.</p>     
                </div>
            </div>
            <div class="card card-bordered">
                <img src="<?= base_url() ?>/assets/img/pelanggan.jpg" class="card-img-top" alt="">
                <div class="card-inner">       
                    <h5 class="card-title"><?= $pelanggan ?> Pelanggan Tetap</h5>
                    <p class="card-text">Restoran Ini Memiliki <?= $pelanggan ?> Pelanggan.</p>  
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function modalHapus(id){
    $('#modal-hapus').modal('show');
    $('#hapus').attr('href', '<?= base_url() ?>/admin/kategori/hapus/'+id+'');
}
function modalEdit(id){
    $("#modal-edit").modal('show');
    $.getJSON('<?php echo base_url() ?>/admin/kategori/get_id/' + id + '', function (data) {
        if (data.data == 1) {
            $('#edit-id').val(data.idkategori);
            $('#edit-kategori').val(data.kategori);
            $('#edit-keterangan').val(data.keterangan);
        }
    });
}
</script>



<?= $this->endSection() ?>